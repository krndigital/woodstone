import MenuController from './MenuController'
import MenuItemController from './MenuItemController'
import MenuCategoryController from './MenuCategoryController'
import StationController from './StationController'

const Menu = {
    MenuController: Object.assign(MenuController, MenuController),
    MenuItemController: Object.assign(MenuItemController, MenuItemController),
    MenuCategoryController: Object.assign(MenuCategoryController, MenuCategoryController),
    StationController: Object.assign(StationController, StationController),
}

export default Menu