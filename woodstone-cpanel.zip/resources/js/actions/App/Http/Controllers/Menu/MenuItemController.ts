import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Menu\MenuItemController::toggleAvailability
* @see app/Http/Controllers/Menu/MenuItemController.php:54
* @route '/menu/items/{item}/availability'
*/
export const toggleAvailability = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleAvailability.url(args, options),
    method: 'patch',
})

toggleAvailability.definition = {
    methods: ["patch"],
    url: '/menu/items/{item}/availability',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Menu\MenuItemController::toggleAvailability
* @see app/Http/Controllers/Menu/MenuItemController.php:54
* @route '/menu/items/{item}/availability'
*/
toggleAvailability.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return toggleAvailability.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Menu\MenuItemController::toggleAvailability
* @see app/Http/Controllers/Menu/MenuItemController.php:54
* @route '/menu/items/{item}/availability'
*/
toggleAvailability.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleAvailability.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::toggleAvailability
* @see app/Http/Controllers/Menu/MenuItemController.php:54
* @route '/menu/items/{item}/availability'
*/
const toggleAvailabilityForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleAvailability.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::toggleAvailability
* @see app/Http/Controllers/Menu/MenuItemController.php:54
* @route '/menu/items/{item}/availability'
*/
toggleAvailabilityForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleAvailability.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

toggleAvailability.form = toggleAvailabilityForm

/**
* @see \App\Http\Controllers\Menu\MenuItemController::store
* @see app/Http/Controllers/Menu/MenuItemController.php:21
* @route '/menu/items'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/menu/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Menu\MenuItemController::store
* @see app/Http/Controllers/Menu/MenuItemController.php:21
* @route '/menu/items'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Menu\MenuItemController::store
* @see app/Http/Controllers/Menu/MenuItemController.php:21
* @route '/menu/items'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::store
* @see app/Http/Controllers/Menu/MenuItemController.php:21
* @route '/menu/items'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::store
* @see app/Http/Controllers/Menu/MenuItemController.php:21
* @route '/menu/items'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Menu\MenuItemController::loadPreset
* @see app/Http/Controllers/Menu/MenuItemController.php:42
* @route '/menu/load-woodstone'
*/
export const loadPreset = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: loadPreset.url(options),
    method: 'post',
})

loadPreset.definition = {
    methods: ["post"],
    url: '/menu/load-woodstone',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Menu\MenuItemController::loadPreset
* @see app/Http/Controllers/Menu/MenuItemController.php:42
* @route '/menu/load-woodstone'
*/
loadPreset.url = (options?: RouteQueryOptions) => {
    return loadPreset.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Menu\MenuItemController::loadPreset
* @see app/Http/Controllers/Menu/MenuItemController.php:42
* @route '/menu/load-woodstone'
*/
loadPreset.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: loadPreset.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::loadPreset
* @see app/Http/Controllers/Menu/MenuItemController.php:42
* @route '/menu/load-woodstone'
*/
const loadPresetForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: loadPreset.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::loadPreset
* @see app/Http/Controllers/Menu/MenuItemController.php:42
* @route '/menu/load-woodstone'
*/
loadPresetForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: loadPreset.url(options),
    method: 'post',
})

loadPreset.form = loadPresetForm

/**
* @see \App\Http\Controllers\Menu\MenuItemController::update
* @see app/Http/Controllers/Menu/MenuItemController.php:30
* @route '/menu/items/{item}'
*/
export const update = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/menu/items/{item}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Menu\MenuItemController::update
* @see app/Http/Controllers/Menu/MenuItemController.php:30
* @route '/menu/items/{item}'
*/
update.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return update.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Menu\MenuItemController::update
* @see app/Http/Controllers/Menu/MenuItemController.php:30
* @route '/menu/items/{item}'
*/
update.put = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::update
* @see app/Http/Controllers/Menu/MenuItemController.php:30
* @route '/menu/items/{item}'
*/
const updateForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::update
* @see app/Http/Controllers/Menu/MenuItemController.php:30
* @route '/menu/items/{item}'
*/
updateForm.put = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Menu\MenuItemController::archive
* @see app/Http/Controllers/Menu/MenuItemController.php:69
* @route '/menu/items/{item}/archive'
*/
export const archive = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: archive.url(args, options),
    method: 'patch',
})

archive.definition = {
    methods: ["patch"],
    url: '/menu/items/{item}/archive',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Menu\MenuItemController::archive
* @see app/Http/Controllers/Menu/MenuItemController.php:69
* @route '/menu/items/{item}/archive'
*/
archive.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return archive.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Menu\MenuItemController::archive
* @see app/Http/Controllers/Menu/MenuItemController.php:69
* @route '/menu/items/{item}/archive'
*/
archive.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: archive.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::archive
* @see app/Http/Controllers/Menu/MenuItemController.php:69
* @route '/menu/items/{item}/archive'
*/
const archiveForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: archive.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::archive
* @see app/Http/Controllers/Menu/MenuItemController.php:69
* @route '/menu/items/{item}/archive'
*/
archiveForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: archive.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

archive.form = archiveForm

/**
* @see \App\Http\Controllers\Menu\MenuItemController::restore
* @see app/Http/Controllers/Menu/MenuItemController.php:79
* @route '/menu/items/{item}/restore'
*/
export const restore = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

restore.definition = {
    methods: ["patch"],
    url: '/menu/items/{item}/restore',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Menu\MenuItemController::restore
* @see app/Http/Controllers/Menu/MenuItemController.php:79
* @route '/menu/items/{item}/restore'
*/
restore.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return restore.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Menu\MenuItemController::restore
* @see app/Http/Controllers/Menu/MenuItemController.php:79
* @route '/menu/items/{item}/restore'
*/
restore.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::restore
* @see app/Http/Controllers/Menu/MenuItemController.php:79
* @route '/menu/items/{item}/restore'
*/
const restoreForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: restore.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::restore
* @see app/Http/Controllers/Menu/MenuItemController.php:79
* @route '/menu/items/{item}/restore'
*/
restoreForm.patch = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: restore.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

restore.form = restoreForm

/**
* @see \App\Http\Controllers\Menu\MenuItemController::uploadImage
* @see app/Http/Controllers/Menu/MenuItemController.php:89
* @route '/menu/items/{item}/image'
*/
export const uploadImage = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadImage.url(args, options),
    method: 'post',
})

uploadImage.definition = {
    methods: ["post"],
    url: '/menu/items/{item}/image',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Menu\MenuItemController::uploadImage
* @see app/Http/Controllers/Menu/MenuItemController.php:89
* @route '/menu/items/{item}/image'
*/
uploadImage.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return uploadImage.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Menu\MenuItemController::uploadImage
* @see app/Http/Controllers/Menu/MenuItemController.php:89
* @route '/menu/items/{item}/image'
*/
uploadImage.post = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadImage.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::uploadImage
* @see app/Http/Controllers/Menu/MenuItemController.php:89
* @route '/menu/items/{item}/image'
*/
const uploadImageForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: uploadImage.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::uploadImage
* @see app/Http/Controllers/Menu/MenuItemController.php:89
* @route '/menu/items/{item}/image'
*/
uploadImageForm.post = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: uploadImage.url(args, options),
    method: 'post',
})

uploadImage.form = uploadImageForm

/**
* @see \App\Http\Controllers\Menu\MenuItemController::removeImage
* @see app/Http/Controllers/Menu/MenuItemController.php:112
* @route '/menu/items/{item}/image'
*/
export const removeImage = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeImage.url(args, options),
    method: 'delete',
})

removeImage.definition = {
    methods: ["delete"],
    url: '/menu/items/{item}/image',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Menu\MenuItemController::removeImage
* @see app/Http/Controllers/Menu/MenuItemController.php:112
* @route '/menu/items/{item}/image'
*/
removeImage.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return removeImage.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Menu\MenuItemController::removeImage
* @see app/Http/Controllers/Menu/MenuItemController.php:112
* @route '/menu/items/{item}/image'
*/
removeImage.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeImage.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::removeImage
* @see app/Http/Controllers/Menu/MenuItemController.php:112
* @route '/menu/items/{item}/image'
*/
const removeImageForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeImage.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::removeImage
* @see app/Http/Controllers/Menu/MenuItemController.php:112
* @route '/menu/items/{item}/image'
*/
removeImageForm.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeImage.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

removeImage.form = removeImageForm

const MenuItemController = { toggleAvailability, store, loadPreset, update, archive, restore, uploadImage, removeImage }

export default MenuItemController