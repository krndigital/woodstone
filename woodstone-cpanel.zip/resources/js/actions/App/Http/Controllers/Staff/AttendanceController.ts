import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Staff\AttendanceController::index
* @see app/Http/Controllers/Staff/AttendanceController.php:21
* @route '/attendance'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/attendance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Staff\AttendanceController::index
* @see app/Http/Controllers/Staff/AttendanceController.php:21
* @route '/attendance'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\AttendanceController::index
* @see app/Http/Controllers/Staff/AttendanceController.php:21
* @route '/attendance'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\AttendanceController::index
* @see app/Http/Controllers/Staff/AttendanceController.php:21
* @route '/attendance'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Staff\AttendanceController::index
* @see app/Http/Controllers/Staff/AttendanceController.php:21
* @route '/attendance'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\AttendanceController::index
* @see app/Http/Controllers/Staff/AttendanceController.php:21
* @route '/attendance'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\AttendanceController::index
* @see app/Http/Controllers/Staff/AttendanceController.php:21
* @route '/attendance'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Staff\AttendanceController::punch
* @see app/Http/Controllers/Staff/AttendanceController.php:35
* @route '/attendance/punch'
*/
export const punch = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: punch.url(options),
    method: 'post',
})

punch.definition = {
    methods: ["post"],
    url: '/attendance/punch',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Staff\AttendanceController::punch
* @see app/Http/Controllers/Staff/AttendanceController.php:35
* @route '/attendance/punch'
*/
punch.url = (options?: RouteQueryOptions) => {
    return punch.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\AttendanceController::punch
* @see app/Http/Controllers/Staff/AttendanceController.php:35
* @route '/attendance/punch'
*/
punch.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: punch.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\AttendanceController::punch
* @see app/Http/Controllers/Staff/AttendanceController.php:35
* @route '/attendance/punch'
*/
const punchForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: punch.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\AttendanceController::punch
* @see app/Http/Controllers/Staff/AttendanceController.php:35
* @route '/attendance/punch'
*/
punchForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: punch.url(options),
    method: 'post',
})

punch.form = punchForm

const AttendanceController = { index, punch }

export default AttendanceController