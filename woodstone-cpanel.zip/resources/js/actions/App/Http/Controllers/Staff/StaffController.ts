import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/staff',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:59
* @route '/staff'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/staff',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:59
* @route '/staff'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:59
* @route '/staff'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:59
* @route '/staff'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:59
* @route '/staff'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:70
* @route '/staff/{staff}'
*/
export const update = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/staff/{staff}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:70
* @route '/staff/{staff}'
*/
update.url = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { staff: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { staff: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            staff: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        staff: typeof args.staff === 'object'
        ? args.staff.id
        : args.staff,
    }

    return update.definition.url
            .replace('{staff}', parsedArgs.staff.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:70
* @route '/staff/{staff}'
*/
update.put = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:70
* @route '/staff/{staff}'
*/
const updateForm = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:70
* @route '/staff/{staff}'
*/
updateForm.put = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Staff\StaffController::advance
* @see app/Http/Controllers/Staff/StaffController.php:81
* @route '/staff/{staff}/advances'
*/
export const advance = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: advance.url(args, options),
    method: 'post',
})

advance.definition = {
    methods: ["post"],
    url: '/staff/{staff}/advances',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::advance
* @see app/Http/Controllers/Staff/StaffController.php:81
* @route '/staff/{staff}/advances'
*/
advance.url = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { staff: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { staff: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            staff: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        staff: typeof args.staff === 'object'
        ? args.staff.id
        : args.staff,
    }

    return advance.definition.url
            .replace('{staff}', parsedArgs.staff.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::advance
* @see app/Http/Controllers/Staff/StaffController.php:81
* @route '/staff/{staff}/advances'
*/
advance.post = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: advance.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::advance
* @see app/Http/Controllers/Staff/StaffController.php:81
* @route '/staff/{staff}/advances'
*/
const advanceForm = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: advance.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::advance
* @see app/Http/Controllers/Staff/StaffController.php:81
* @route '/staff/{staff}/advances'
*/
advanceForm.post = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: advance.url(args, options),
    method: 'post',
})

advance.form = advanceForm

/**
* @see \App\Http\Controllers\Staff\StaffController::markAttendance
* @see app/Http/Controllers/Staff/StaffController.php:109
* @route '/staff/{staff}/attendance'
*/
export const markAttendance = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: markAttendance.url(args, options),
    method: 'put',
})

markAttendance.definition = {
    methods: ["put"],
    url: '/staff/{staff}/attendance',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::markAttendance
* @see app/Http/Controllers/Staff/StaffController.php:109
* @route '/staff/{staff}/attendance'
*/
markAttendance.url = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { staff: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { staff: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            staff: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        staff: typeof args.staff === 'object'
        ? args.staff.id
        : args.staff,
    }

    return markAttendance.definition.url
            .replace('{staff}', parsedArgs.staff.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::markAttendance
* @see app/Http/Controllers/Staff/StaffController.php:109
* @route '/staff/{staff}/attendance'
*/
markAttendance.put = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: markAttendance.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::markAttendance
* @see app/Http/Controllers/Staff/StaffController.php:109
* @route '/staff/{staff}/attendance'
*/
const markAttendanceForm = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markAttendance.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::markAttendance
* @see app/Http/Controllers/Staff/StaffController.php:109
* @route '/staff/{staff}/attendance'
*/
markAttendanceForm.put = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markAttendance.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

markAttendance.form = markAttendanceForm

/**
* @see \App\Http\Controllers\Staff\StaffController::storeLeave
* @see app/Http/Controllers/Staff/StaffController.php:89
* @route '/staff/leaves'
*/
export const storeLeave = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeLeave.url(options),
    method: 'post',
})

storeLeave.definition = {
    methods: ["post"],
    url: '/staff/leaves',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::storeLeave
* @see app/Http/Controllers/Staff/StaffController.php:89
* @route '/staff/leaves'
*/
storeLeave.url = (options?: RouteQueryOptions) => {
    return storeLeave.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::storeLeave
* @see app/Http/Controllers/Staff/StaffController.php:89
* @route '/staff/leaves'
*/
storeLeave.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeLeave.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::storeLeave
* @see app/Http/Controllers/Staff/StaffController.php:89
* @route '/staff/leaves'
*/
const storeLeaveForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeLeave.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::storeLeave
* @see app/Http/Controllers/Staff/StaffController.php:89
* @route '/staff/leaves'
*/
storeLeaveForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeLeave.url(options),
    method: 'post',
})

storeLeave.form = storeLeaveForm

/**
* @see \App\Http\Controllers\Staff\StaffController::decideLeave
* @see app/Http/Controllers/Staff/StaffController.php:101
* @route '/staff/leaves/{leave}'
*/
export const decideLeave = (args: { leave: number | { id: number } } | [leave: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: decideLeave.url(args, options),
    method: 'patch',
})

decideLeave.definition = {
    methods: ["patch"],
    url: '/staff/leaves/{leave}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::decideLeave
* @see app/Http/Controllers/Staff/StaffController.php:101
* @route '/staff/leaves/{leave}'
*/
decideLeave.url = (args: { leave: number | { id: number } } | [leave: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leave: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { leave: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            leave: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        leave: typeof args.leave === 'object'
        ? args.leave.id
        : args.leave,
    }

    return decideLeave.definition.url
            .replace('{leave}', parsedArgs.leave.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::decideLeave
* @see app/Http/Controllers/Staff/StaffController.php:101
* @route '/staff/leaves/{leave}'
*/
decideLeave.patch = (args: { leave: number | { id: number } } | [leave: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: decideLeave.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::decideLeave
* @see app/Http/Controllers/Staff/StaffController.php:101
* @route '/staff/leaves/{leave}'
*/
const decideLeaveForm = (args: { leave: number | { id: number } } | [leave: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: decideLeave.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::decideLeave
* @see app/Http/Controllers/Staff/StaffController.php:101
* @route '/staff/leaves/{leave}'
*/
decideLeaveForm.patch = (args: { leave: number | { id: number } } | [leave: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: decideLeave.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

decideLeave.form = decideLeaveForm

const StaffController = { index, store, update, advance, markAttendance, storeLeave, decideLeave }

export default StaffController