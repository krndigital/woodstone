import StaffController from './StaffController'
import PayrollController from './PayrollController'
import AttendanceController from './AttendanceController'

const Staff = {
    StaffController: Object.assign(StaffController, StaffController),
    PayrollController: Object.assign(PayrollController, PayrollController),
    AttendanceController: Object.assign(AttendanceController, AttendanceController),
}

export default Staff