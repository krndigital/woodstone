import PinLoginController from './PinLoginController'

const Auth = {
    PinLoginController: Object.assign(PinLoginController, PinLoginController),
}

export default Auth