import CustomerController from './CustomerController'

const Dues = {
    CustomerController: Object.assign(CustomerController, CustomerController),
}

export default Dues