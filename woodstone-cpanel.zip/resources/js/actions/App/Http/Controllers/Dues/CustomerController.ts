import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Dues\CustomerController::index
* @see app/Http/Controllers/Dues/CustomerController.php:41
* @route '/customers'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/customers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Dues\CustomerController::index
* @see app/Http/Controllers/Dues/CustomerController.php:41
* @route '/customers'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Dues\CustomerController::index
* @see app/Http/Controllers/Dues/CustomerController.php:41
* @route '/customers'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::index
* @see app/Http/Controllers/Dues/CustomerController.php:41
* @route '/customers'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::index
* @see app/Http/Controllers/Dues/CustomerController.php:41
* @route '/customers'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::index
* @see app/Http/Controllers/Dues/CustomerController.php:41
* @route '/customers'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::index
* @see app/Http/Controllers/Dues/CustomerController.php:41
* @route '/customers'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Dues\CustomerController::store
* @see app/Http/Controllers/Dues/CustomerController.php:152
* @route '/customers'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/customers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Dues\CustomerController::store
* @see app/Http/Controllers/Dues/CustomerController.php:152
* @route '/customers'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Dues\CustomerController::store
* @see app/Http/Controllers/Dues/CustomerController.php:152
* @route '/customers'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::store
* @see app/Http/Controllers/Dues/CustomerController.php:152
* @route '/customers'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::store
* @see app/Http/Controllers/Dues/CustomerController.php:152
* @route '/customers'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Dues\CustomerController::show
* @see app/Http/Controllers/Dues/CustomerController.php:105
* @route '/customers/{customer}'
*/
export const show = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/customers/{customer}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Dues\CustomerController::show
* @see app/Http/Controllers/Dues/CustomerController.php:105
* @route '/customers/{customer}'
*/
show.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return show.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Dues\CustomerController::show
* @see app/Http/Controllers/Dues/CustomerController.php:105
* @route '/customers/{customer}'
*/
show.get = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::show
* @see app/Http/Controllers/Dues/CustomerController.php:105
* @route '/customers/{customer}'
*/
show.head = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::show
* @see app/Http/Controllers/Dues/CustomerController.php:105
* @route '/customers/{customer}'
*/
const showForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::show
* @see app/Http/Controllers/Dues/CustomerController.php:105
* @route '/customers/{customer}'
*/
showForm.get = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::show
* @see app/Http/Controllers/Dues/CustomerController.php:105
* @route '/customers/{customer}'
*/
showForm.head = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Dues\CustomerController::update
* @see app/Http/Controllers/Dues/CustomerController.php:174
* @route '/customers/{customer}'
*/
export const update = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/customers/{customer}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Dues\CustomerController::update
* @see app/Http/Controllers/Dues/CustomerController.php:174
* @route '/customers/{customer}'
*/
update.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return update.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Dues\CustomerController::update
* @see app/Http/Controllers/Dues/CustomerController.php:174
* @route '/customers/{customer}'
*/
update.put = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::update
* @see app/Http/Controllers/Dues/CustomerController.php:174
* @route '/customers/{customer}'
*/
const updateForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::update
* @see app/Http/Controllers/Dues/CustomerController.php:174
* @route '/customers/{customer}'
*/
updateForm.put = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Dues\CustomerController::receive
* @see app/Http/Controllers/Dues/CustomerController.php:199
* @route '/customers/{customer}/payments'
*/
export const receive = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: receive.url(args, options),
    method: 'post',
})

receive.definition = {
    methods: ["post"],
    url: '/customers/{customer}/payments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Dues\CustomerController::receive
* @see app/Http/Controllers/Dues/CustomerController.php:199
* @route '/customers/{customer}/payments'
*/
receive.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return receive.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Dues\CustomerController::receive
* @see app/Http/Controllers/Dues/CustomerController.php:199
* @route '/customers/{customer}/payments'
*/
receive.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: receive.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::receive
* @see app/Http/Controllers/Dues/CustomerController.php:199
* @route '/customers/{customer}/payments'
*/
const receiveForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: receive.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::receive
* @see app/Http/Controllers/Dues/CustomerController.php:199
* @route '/customers/{customer}/payments'
*/
receiveForm.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: receive.url(args, options),
    method: 'post',
})

receive.form = receiveForm

/**
* @see \App\Http\Controllers\Dues\CustomerController::move
* @see app/Http/Controllers/Dues/CustomerController.php:254
* @route '/customers/{customer}/move'
*/
export const move = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: move.url(args, options),
    method: 'post',
})

move.definition = {
    methods: ["post"],
    url: '/customers/{customer}/move',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Dues\CustomerController::move
* @see app/Http/Controllers/Dues/CustomerController.php:254
* @route '/customers/{customer}/move'
*/
move.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return move.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Dues\CustomerController::move
* @see app/Http/Controllers/Dues/CustomerController.php:254
* @route '/customers/{customer}/move'
*/
move.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: move.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::move
* @see app/Http/Controllers/Dues/CustomerController.php:254
* @route '/customers/{customer}/move'
*/
const moveForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: move.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::move
* @see app/Http/Controllers/Dues/CustomerController.php:254
* @route '/customers/{customer}/move'
*/
moveForm.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: move.url(args, options),
    method: 'post',
})

move.form = moveForm

/**
* @see \App\Http\Controllers\Dues\CustomerController::storeGroup
* @see app/Http/Controllers/Dues/CustomerController.php:270
* @route '/customer-groups'
*/
export const storeGroup = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeGroup.url(options),
    method: 'post',
})

storeGroup.definition = {
    methods: ["post"],
    url: '/customer-groups',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Dues\CustomerController::storeGroup
* @see app/Http/Controllers/Dues/CustomerController.php:270
* @route '/customer-groups'
*/
storeGroup.url = (options?: RouteQueryOptions) => {
    return storeGroup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Dues\CustomerController::storeGroup
* @see app/Http/Controllers/Dues/CustomerController.php:270
* @route '/customer-groups'
*/
storeGroup.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeGroup.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::storeGroup
* @see app/Http/Controllers/Dues/CustomerController.php:270
* @route '/customer-groups'
*/
const storeGroupForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeGroup.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::storeGroup
* @see app/Http/Controllers/Dues/CustomerController.php:270
* @route '/customer-groups'
*/
storeGroupForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeGroup.url(options),
    method: 'post',
})

storeGroup.form = storeGroupForm

/**
* @see \App\Http\Controllers\Dues\CustomerController::statement
* @see app/Http/Controllers/Dues/CustomerController.php:242
* @route '/customers/{customer}/statement'
*/
export const statement = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statement.url(args, options),
    method: 'get',
})

statement.definition = {
    methods: ["get","head"],
    url: '/customers/{customer}/statement',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Dues\CustomerController::statement
* @see app/Http/Controllers/Dues/CustomerController.php:242
* @route '/customers/{customer}/statement'
*/
statement.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { customer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            customer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        customer: typeof args.customer === 'object'
        ? args.customer.id
        : args.customer,
    }

    return statement.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Dues\CustomerController::statement
* @see app/Http/Controllers/Dues/CustomerController.php:242
* @route '/customers/{customer}/statement'
*/
statement.get = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statement.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::statement
* @see app/Http/Controllers/Dues/CustomerController.php:242
* @route '/customers/{customer}/statement'
*/
statement.head = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: statement.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::statement
* @see app/Http/Controllers/Dues/CustomerController.php:242
* @route '/customers/{customer}/statement'
*/
const statementForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: statement.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::statement
* @see app/Http/Controllers/Dues/CustomerController.php:242
* @route '/customers/{customer}/statement'
*/
statementForm.get = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: statement.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::statement
* @see app/Http/Controllers/Dues/CustomerController.php:242
* @route '/customers/{customer}/statement'
*/
statementForm.head = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: statement.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

statement.form = statementForm

/**
* @see \App\Http\Controllers\Dues\CustomerController::receipt
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
export const receipt = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipt.url(args, options),
    method: 'get',
})

receipt.definition = {
    methods: ["get","head"],
    url: '/customer-receipts/{entry}/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Dues\CustomerController::receipt
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
receipt.url = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { entry: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { entry: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            entry: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        entry: typeof args.entry === 'object'
        ? args.entry.id
        : args.entry,
    }

    return receipt.definition.url
            .replace('{entry}', parsedArgs.entry.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Dues\CustomerController::receipt
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
receipt.get = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipt.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::receipt
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
receipt.head = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: receipt.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::receipt
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
const receiptForm = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipt.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::receipt
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
receiptForm.get = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipt.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::receipt
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
receiptForm.head = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipt.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

receipt.form = receiptForm

const CustomerController = { index, store, show, update, receive, move, storeGroup, statement, receipt }

export default CustomerController