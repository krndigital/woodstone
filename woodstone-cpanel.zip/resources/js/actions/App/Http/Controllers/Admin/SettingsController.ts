import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:34
* @route '/admin/settings'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/settings',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:34
* @route '/admin/settings'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:34
* @route '/admin/settings'
*/
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:34
* @route '/admin/settings'
*/
const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:34
* @route '/admin/settings'
*/
updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\SettingsController::uploadBranding
* @see app/Http/Controllers/Admin/SettingsController.php:70
* @route '/admin/settings/branding'
*/
export const uploadBranding = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadBranding.url(options),
    method: 'post',
})

uploadBranding.definition = {
    methods: ["post"],
    url: '/admin/settings/branding',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SettingsController::uploadBranding
* @see app/Http/Controllers/Admin/SettingsController.php:70
* @route '/admin/settings/branding'
*/
uploadBranding.url = (options?: RouteQueryOptions) => {
    return uploadBranding.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SettingsController::uploadBranding
* @see app/Http/Controllers/Admin/SettingsController.php:70
* @route '/admin/settings/branding'
*/
uploadBranding.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadBranding.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::uploadBranding
* @see app/Http/Controllers/Admin/SettingsController.php:70
* @route '/admin/settings/branding'
*/
const uploadBrandingForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: uploadBranding.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::uploadBranding
* @see app/Http/Controllers/Admin/SettingsController.php:70
* @route '/admin/settings/branding'
*/
uploadBrandingForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: uploadBranding.url(options),
    method: 'post',
})

uploadBranding.form = uploadBrandingForm

/**
* @see \App\Http\Controllers\Admin\SettingsController::removeBranding
* @see app/Http/Controllers/Admin/SettingsController.php:91
* @route '/admin/settings/branding/{kind}'
*/
export const removeBranding = (args: { kind: string | number } | [kind: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeBranding.url(args, options),
    method: 'delete',
})

removeBranding.definition = {
    methods: ["delete"],
    url: '/admin/settings/branding/{kind}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\SettingsController::removeBranding
* @see app/Http/Controllers/Admin/SettingsController.php:91
* @route '/admin/settings/branding/{kind}'
*/
removeBranding.url = (args: { kind: string | number } | [kind: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kind: args }
    }

    if (Array.isArray(args)) {
        args = {
            kind: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kind: args.kind,
    }

    return removeBranding.definition.url
            .replace('{kind}', parsedArgs.kind.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SettingsController::removeBranding
* @see app/Http/Controllers/Admin/SettingsController.php:91
* @route '/admin/settings/branding/{kind}'
*/
removeBranding.delete = (args: { kind: string | number } | [kind: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeBranding.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::removeBranding
* @see app/Http/Controllers/Admin/SettingsController.php:91
* @route '/admin/settings/branding/{kind}'
*/
const removeBrandingForm = (args: { kind: string | number } | [kind: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeBranding.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::removeBranding
* @see app/Http/Controllers/Admin/SettingsController.php:91
* @route '/admin/settings/branding/{kind}'
*/
removeBrandingForm.delete = (args: { kind: string | number } | [kind: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeBranding.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

removeBranding.form = removeBrandingForm

const SettingsController = { edit, update, uploadBranding, removeBranding }

export default SettingsController