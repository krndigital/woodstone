import SettingsController from './SettingsController'
import RoleController from './RoleController'

const Admin = {
    SettingsController: Object.assign(SettingsController, SettingsController),
    RoleController: Object.assign(RoleController, RoleController),
}

export default Admin