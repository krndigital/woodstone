import FloorController from './FloorController'
import ReservationController from './ReservationController'

const Floor = {
    FloorController: Object.assign(FloorController, FloorController),
    ReservationController: Object.assign(ReservationController, ReservationController),
}

export default Floor