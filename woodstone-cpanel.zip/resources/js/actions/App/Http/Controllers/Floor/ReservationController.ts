import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Floor\ReservationController::index
* @see app/Http/Controllers/Floor/ReservationController.php:25
* @route '/reservations'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/reservations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Floor\ReservationController::index
* @see app/Http/Controllers/Floor/ReservationController.php:25
* @route '/reservations'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\ReservationController::index
* @see app/Http/Controllers/Floor/ReservationController.php:25
* @route '/reservations'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\ReservationController::index
* @see app/Http/Controllers/Floor/ReservationController.php:25
* @route '/reservations'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Floor\ReservationController::index
* @see app/Http/Controllers/Floor/ReservationController.php:25
* @route '/reservations'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\ReservationController::index
* @see app/Http/Controllers/Floor/ReservationController.php:25
* @route '/reservations'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\ReservationController::index
* @see app/Http/Controllers/Floor/ReservationController.php:25
* @route '/reservations'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Floor\ReservationController::store
* @see app/Http/Controllers/Floor/ReservationController.php:46
* @route '/reservations'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/reservations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Floor\ReservationController::store
* @see app/Http/Controllers/Floor/ReservationController.php:46
* @route '/reservations'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\ReservationController::store
* @see app/Http/Controllers/Floor/ReservationController.php:46
* @route '/reservations'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\ReservationController::store
* @see app/Http/Controllers/Floor/ReservationController.php:46
* @route '/reservations'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\ReservationController::store
* @see app/Http/Controllers/Floor/ReservationController.php:46
* @route '/reservations'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Floor\ReservationController::seat
* @see app/Http/Controllers/Floor/ReservationController.php:63
* @route '/reservations/{reservation}/seat'
*/
export const seat = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: seat.url(args, options),
    method: 'post',
})

seat.definition = {
    methods: ["post"],
    url: '/reservations/{reservation}/seat',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Floor\ReservationController::seat
* @see app/Http/Controllers/Floor/ReservationController.php:63
* @route '/reservations/{reservation}/seat'
*/
seat.url = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { reservation: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { reservation: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            reservation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        reservation: typeof args.reservation === 'object'
        ? args.reservation.id
        : args.reservation,
    }

    return seat.definition.url
            .replace('{reservation}', parsedArgs.reservation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\ReservationController::seat
* @see app/Http/Controllers/Floor/ReservationController.php:63
* @route '/reservations/{reservation}/seat'
*/
seat.post = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: seat.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\ReservationController::seat
* @see app/Http/Controllers/Floor/ReservationController.php:63
* @route '/reservations/{reservation}/seat'
*/
const seatForm = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: seat.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\ReservationController::seat
* @see app/Http/Controllers/Floor/ReservationController.php:63
* @route '/reservations/{reservation}/seat'
*/
seatForm.post = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: seat.url(args, options),
    method: 'post',
})

seat.form = seatForm

/**
* @see \App\Http\Controllers\Floor\ReservationController::close
* @see app/Http/Controllers/Floor/ReservationController.php:73
* @route '/reservations/{reservation}/close'
*/
export const close = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(args, options),
    method: 'post',
})

close.definition = {
    methods: ["post"],
    url: '/reservations/{reservation}/close',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Floor\ReservationController::close
* @see app/Http/Controllers/Floor/ReservationController.php:73
* @route '/reservations/{reservation}/close'
*/
close.url = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { reservation: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { reservation: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            reservation: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        reservation: typeof args.reservation === 'object'
        ? args.reservation.id
        : args.reservation,
    }

    return close.definition.url
            .replace('{reservation}', parsedArgs.reservation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\ReservationController::close
* @see app/Http/Controllers/Floor/ReservationController.php:73
* @route '/reservations/{reservation}/close'
*/
close.post = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\ReservationController::close
* @see app/Http/Controllers/Floor/ReservationController.php:73
* @route '/reservations/{reservation}/close'
*/
const closeForm = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: close.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\ReservationController::close
* @see app/Http/Controllers/Floor/ReservationController.php:73
* @route '/reservations/{reservation}/close'
*/
closeForm.post = (args: { reservation: number | { id: number } } | [reservation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: close.url(args, options),
    method: 'post',
})

close.form = closeForm

const ReservationController = { index, store, seat, close }

export default ReservationController