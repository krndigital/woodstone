import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/floor',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Floor\FloorController::updateStatus
* @see app/Http/Controllers/Floor/FloorController.php:48
* @route '/floor/tables/{table}/status'
*/
export const updateStatus = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/floor/tables/{table}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::updateStatus
* @see app/Http/Controllers/Floor/FloorController.php:48
* @route '/floor/tables/{table}/status'
*/
updateStatus.url = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { table: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { table: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            table: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        table: typeof args.table === 'object'
        ? args.table.id
        : args.table,
    }

    return updateStatus.definition.url
            .replace('{table}', parsedArgs.table.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::updateStatus
* @see app/Http/Controllers/Floor/FloorController.php:48
* @route '/floor/tables/{table}/status'
*/
updateStatus.patch = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::updateStatus
* @see app/Http/Controllers/Floor/FloorController.php:48
* @route '/floor/tables/{table}/status'
*/
const updateStatusForm = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateStatus.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::updateStatus
* @see app/Http/Controllers/Floor/FloorController.php:48
* @route '/floor/tables/{table}/status'
*/
updateStatusForm.patch = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateStatus.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateStatus.form = updateStatusForm

/**
* @see \App\Http\Controllers\Floor\FloorController::storeZone
* @see app/Http/Controllers/Floor/FloorController.php:67
* @route '/floor/zones'
*/
export const storeZone = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeZone.url(options),
    method: 'post',
})

storeZone.definition = {
    methods: ["post"],
    url: '/floor/zones',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::storeZone
* @see app/Http/Controllers/Floor/FloorController.php:67
* @route '/floor/zones'
*/
storeZone.url = (options?: RouteQueryOptions) => {
    return storeZone.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::storeZone
* @see app/Http/Controllers/Floor/FloorController.php:67
* @route '/floor/zones'
*/
storeZone.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeZone.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::storeZone
* @see app/Http/Controllers/Floor/FloorController.php:67
* @route '/floor/zones'
*/
const storeZoneForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeZone.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::storeZone
* @see app/Http/Controllers/Floor/FloorController.php:67
* @route '/floor/zones'
*/
storeZoneForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeZone.url(options),
    method: 'post',
})

storeZone.form = storeZoneForm

/**
* @see \App\Http\Controllers\Floor\FloorController::updateZone
* @see app/Http/Controllers/Floor/FloorController.php:79
* @route '/floor/zones/{zone}'
*/
export const updateZone = (args: { zone: number | { id: number } } | [zone: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateZone.url(args, options),
    method: 'put',
})

updateZone.definition = {
    methods: ["put"],
    url: '/floor/zones/{zone}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::updateZone
* @see app/Http/Controllers/Floor/FloorController.php:79
* @route '/floor/zones/{zone}'
*/
updateZone.url = (args: { zone: number | { id: number } } | [zone: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { zone: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { zone: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            zone: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        zone: typeof args.zone === 'object'
        ? args.zone.id
        : args.zone,
    }

    return updateZone.definition.url
            .replace('{zone}', parsedArgs.zone.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::updateZone
* @see app/Http/Controllers/Floor/FloorController.php:79
* @route '/floor/zones/{zone}'
*/
updateZone.put = (args: { zone: number | { id: number } } | [zone: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateZone.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::updateZone
* @see app/Http/Controllers/Floor/FloorController.php:79
* @route '/floor/zones/{zone}'
*/
const updateZoneForm = (args: { zone: number | { id: number } } | [zone: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateZone.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::updateZone
* @see app/Http/Controllers/Floor/FloorController.php:79
* @route '/floor/zones/{zone}'
*/
updateZoneForm.put = (args: { zone: number | { id: number } } | [zone: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateZone.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateZone.form = updateZoneForm

/**
* @see \App\Http\Controllers\Floor\FloorController::storeTable
* @see app/Http/Controllers/Floor/FloorController.php:92
* @route '/floor/tables'
*/
export const storeTable = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTable.url(options),
    method: 'post',
})

storeTable.definition = {
    methods: ["post"],
    url: '/floor/tables',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::storeTable
* @see app/Http/Controllers/Floor/FloorController.php:92
* @route '/floor/tables'
*/
storeTable.url = (options?: RouteQueryOptions) => {
    return storeTable.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::storeTable
* @see app/Http/Controllers/Floor/FloorController.php:92
* @route '/floor/tables'
*/
storeTable.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTable.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::storeTable
* @see app/Http/Controllers/Floor/FloorController.php:92
* @route '/floor/tables'
*/
const storeTableForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeTable.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::storeTable
* @see app/Http/Controllers/Floor/FloorController.php:92
* @route '/floor/tables'
*/
storeTableForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeTable.url(options),
    method: 'post',
})

storeTable.form = storeTableForm

/**
* @see \App\Http\Controllers\Floor\FloorController::updateTable
* @see app/Http/Controllers/Floor/FloorController.php:124
* @route '/floor/tables/{table}'
*/
export const updateTable = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateTable.url(args, options),
    method: 'put',
})

updateTable.definition = {
    methods: ["put"],
    url: '/floor/tables/{table}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::updateTable
* @see app/Http/Controllers/Floor/FloorController.php:124
* @route '/floor/tables/{table}'
*/
updateTable.url = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { table: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { table: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            table: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        table: typeof args.table === 'object'
        ? args.table.id
        : args.table,
    }

    return updateTable.definition.url
            .replace('{table}', parsedArgs.table.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::updateTable
* @see app/Http/Controllers/Floor/FloorController.php:124
* @route '/floor/tables/{table}'
*/
updateTable.put = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateTable.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::updateTable
* @see app/Http/Controllers/Floor/FloorController.php:124
* @route '/floor/tables/{table}'
*/
const updateTableForm = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateTable.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::updateTable
* @see app/Http/Controllers/Floor/FloorController.php:124
* @route '/floor/tables/{table}'
*/
updateTableForm.put = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateTable.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateTable.form = updateTableForm

/**
* @see \App\Http\Controllers\Floor\FloorController::regenerateQr
* @see app/Http/Controllers/Floor/FloorController.php:102
* @route '/floor/tables/{table}/qr'
*/
export const regenerateQr = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateQr.url(args, options),
    method: 'post',
})

regenerateQr.definition = {
    methods: ["post"],
    url: '/floor/tables/{table}/qr',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::regenerateQr
* @see app/Http/Controllers/Floor/FloorController.php:102
* @route '/floor/tables/{table}/qr'
*/
regenerateQr.url = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { table: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { table: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            table: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        table: typeof args.table === 'object'
        ? args.table.id
        : args.table,
    }

    return regenerateQr.definition.url
            .replace('{table}', parsedArgs.table.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::regenerateQr
* @see app/Http/Controllers/Floor/FloorController.php:102
* @route '/floor/tables/{table}/qr'
*/
regenerateQr.post = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateQr.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::regenerateQr
* @see app/Http/Controllers/Floor/FloorController.php:102
* @route '/floor/tables/{table}/qr'
*/
const regenerateQrForm = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: regenerateQr.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::regenerateQr
* @see app/Http/Controllers/Floor/FloorController.php:102
* @route '/floor/tables/{table}/qr'
*/
regenerateQrForm.post = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: regenerateQr.url(args, options),
    method: 'post',
})

regenerateQr.form = regenerateQrForm

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
export const qrCards = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qrCards.url(options),
    method: 'get',
})

qrCards.definition = {
    methods: ["get","head"],
    url: '/floor/qr-cards',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
qrCards.url = (options?: RouteQueryOptions) => {
    return qrCards.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
qrCards.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qrCards.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
qrCards.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: qrCards.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
const qrCardsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qrCards.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
qrCardsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qrCards.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
qrCardsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qrCards.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

qrCards.form = qrCardsForm

const FloorController = { index, updateStatus, storeZone, updateZone, storeTable, updateTable, regenerateQr, qrCards }

export default FloorController