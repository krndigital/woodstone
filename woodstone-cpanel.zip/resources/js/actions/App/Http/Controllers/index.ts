import Guest from './Guest'
import Auth from './Auth'
import DashboardController from './DashboardController'
import UserController from './UserController'
import Admin from './Admin'
import Floor from './Floor'
import Pos from './Pos'
import Billing from './Billing'
import Dues from './Dues'
import Accounting from './Accounting'
import Money from './Money'
import Staff from './Staff'
import Reports from './Reports'
import Stock from './Stock'
import Kitchen from './Kitchen'
import Menu from './Menu'
import TerminalController from './TerminalController'
import Settings from './Settings'

const Controllers = {
    Guest: Object.assign(Guest, Guest),
    Auth: Object.assign(Auth, Auth),
    DashboardController: Object.assign(DashboardController, DashboardController),
    UserController: Object.assign(UserController, UserController),
    Admin: Object.assign(Admin, Admin),
    Floor: Object.assign(Floor, Floor),
    Pos: Object.assign(Pos, Pos),
    Billing: Object.assign(Billing, Billing),
    Dues: Object.assign(Dues, Dues),
    Accounting: Object.assign(Accounting, Accounting),
    Money: Object.assign(Money, Money),
    Staff: Object.assign(Staff, Staff),
    Reports: Object.assign(Reports, Reports),
    Stock: Object.assign(Stock, Stock),
    Kitchen: Object.assign(Kitchen, Kitchen),
    Menu: Object.assign(Menu, Menu),
    TerminalController: Object.assign(TerminalController, TerminalController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers