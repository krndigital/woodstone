import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Stock\StockItemController::index
* @see app/Http/Controllers/Stock/StockItemController.php:29
* @route '/stock'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/stock',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Stock\StockItemController::index
* @see app/Http/Controllers/Stock/StockItemController.php:29
* @route '/stock'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\StockItemController::index
* @see app/Http/Controllers/Stock/StockItemController.php:29
* @route '/stock'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\StockItemController::index
* @see app/Http/Controllers/Stock/StockItemController.php:29
* @route '/stock'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Stock\StockItemController::index
* @see app/Http/Controllers/Stock/StockItemController.php:29
* @route '/stock'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\StockItemController::index
* @see app/Http/Controllers/Stock/StockItemController.php:29
* @route '/stock'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\StockItemController::index
* @see app/Http/Controllers/Stock/StockItemController.php:29
* @route '/stock'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Stock\StockItemController::store
* @see app/Http/Controllers/Stock/StockItemController.php:68
* @route '/stock/items'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/stock/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Stock\StockItemController::store
* @see app/Http/Controllers/Stock/StockItemController.php:68
* @route '/stock/items'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\StockItemController::store
* @see app/Http/Controllers/Stock/StockItemController.php:68
* @route '/stock/items'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\StockItemController::store
* @see app/Http/Controllers/Stock/StockItemController.php:68
* @route '/stock/items'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\StockItemController::store
* @see app/Http/Controllers/Stock/StockItemController.php:68
* @route '/stock/items'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Stock\StockItemController::update
* @see app/Http/Controllers/Stock/StockItemController.php:78
* @route '/stock/items/{stockItem}'
*/
export const update = (args: { stockItem: number | { id: number } } | [stockItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/stock/items/{stockItem}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Stock\StockItemController::update
* @see app/Http/Controllers/Stock/StockItemController.php:78
* @route '/stock/items/{stockItem}'
*/
update.url = (args: { stockItem: number | { id: number } } | [stockItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { stockItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { stockItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            stockItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        stockItem: typeof args.stockItem === 'object'
        ? args.stockItem.id
        : args.stockItem,
    }

    return update.definition.url
            .replace('{stockItem}', parsedArgs.stockItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\StockItemController::update
* @see app/Http/Controllers/Stock/StockItemController.php:78
* @route '/stock/items/{stockItem}'
*/
update.put = (args: { stockItem: number | { id: number } } | [stockItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Stock\StockItemController::update
* @see app/Http/Controllers/Stock/StockItemController.php:78
* @route '/stock/items/{stockItem}'
*/
const updateForm = (args: { stockItem: number | { id: number } } | [stockItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\StockItemController::update
* @see app/Http/Controllers/Stock/StockItemController.php:78
* @route '/stock/items/{stockItem}'
*/
updateForm.put = (args: { stockItem: number | { id: number } } | [stockItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Stock\StockItemController::adjust
* @see app/Http/Controllers/Stock/StockItemController.php:87
* @route '/stock/items/{stockItem}/adjust'
*/
export const adjust = (args: { stockItem: number | { id: number } } | [stockItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjust.url(args, options),
    method: 'post',
})

adjust.definition = {
    methods: ["post"],
    url: '/stock/items/{stockItem}/adjust',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Stock\StockItemController::adjust
* @see app/Http/Controllers/Stock/StockItemController.php:87
* @route '/stock/items/{stockItem}/adjust'
*/
adjust.url = (args: { stockItem: number | { id: number } } | [stockItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { stockItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { stockItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            stockItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        stockItem: typeof args.stockItem === 'object'
        ? args.stockItem.id
        : args.stockItem,
    }

    return adjust.definition.url
            .replace('{stockItem}', parsedArgs.stockItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\StockItemController::adjust
* @see app/Http/Controllers/Stock/StockItemController.php:87
* @route '/stock/items/{stockItem}/adjust'
*/
adjust.post = (args: { stockItem: number | { id: number } } | [stockItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjust.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\StockItemController::adjust
* @see app/Http/Controllers/Stock/StockItemController.php:87
* @route '/stock/items/{stockItem}/adjust'
*/
const adjustForm = (args: { stockItem: number | { id: number } } | [stockItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: adjust.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\StockItemController::adjust
* @see app/Http/Controllers/Stock/StockItemController.php:87
* @route '/stock/items/{stockItem}/adjust'
*/
adjustForm.post = (args: { stockItem: number | { id: number } } | [stockItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: adjust.url(args, options),
    method: 'post',
})

adjust.form = adjustForm

const StockItemController = { index, store, update, adjust }

export default StockItemController