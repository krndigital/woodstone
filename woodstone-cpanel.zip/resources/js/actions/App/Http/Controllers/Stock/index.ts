import StockItemController from './StockItemController'
import PurchaseController from './PurchaseController'
import PurchaseOrderController from './PurchaseOrderController'
import SupplierController from './SupplierController'
import RecipeController from './RecipeController'

const Stock = {
    StockItemController: Object.assign(StockItemController, StockItemController),
    PurchaseController: Object.assign(PurchaseController, PurchaseController),
    PurchaseOrderController: Object.assign(PurchaseOrderController, PurchaseOrderController),
    SupplierController: Object.assign(SupplierController, SupplierController),
    RecipeController: Object.assign(RecipeController, RecipeController),
}

export default Stock