import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Stock\SupplierController::index
* @see app/Http/Controllers/Stock/SupplierController.php:33
* @route '/stock/suppliers'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/stock/suppliers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Stock\SupplierController::index
* @see app/Http/Controllers/Stock/SupplierController.php:33
* @route '/stock/suppliers'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\SupplierController::index
* @see app/Http/Controllers/Stock/SupplierController.php:33
* @route '/stock/suppliers'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::index
* @see app/Http/Controllers/Stock/SupplierController.php:33
* @route '/stock/suppliers'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::index
* @see app/Http/Controllers/Stock/SupplierController.php:33
* @route '/stock/suppliers'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::index
* @see app/Http/Controllers/Stock/SupplierController.php:33
* @route '/stock/suppliers'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::index
* @see app/Http/Controllers/Stock/SupplierController.php:33
* @route '/stock/suppliers'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Stock\SupplierController::store
* @see app/Http/Controllers/Stock/SupplierController.php:95
* @route '/stock/suppliers'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/stock/suppliers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Stock\SupplierController::store
* @see app/Http/Controllers/Stock/SupplierController.php:95
* @route '/stock/suppliers'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\SupplierController::store
* @see app/Http/Controllers/Stock/SupplierController.php:95
* @route '/stock/suppliers'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::store
* @see app/Http/Controllers/Stock/SupplierController.php:95
* @route '/stock/suppliers'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::store
* @see app/Http/Controllers/Stock/SupplierController.php:95
* @route '/stock/suppliers'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Stock\SupplierController::update
* @see app/Http/Controllers/Stock/SupplierController.php:109
* @route '/stock/suppliers/{supplier}'
*/
export const update = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/stock/suppliers/{supplier}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Stock\SupplierController::update
* @see app/Http/Controllers/Stock/SupplierController.php:109
* @route '/stock/suppliers/{supplier}'
*/
update.url = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { supplier: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { supplier: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            supplier: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        supplier: typeof args.supplier === 'object'
        ? args.supplier.id
        : args.supplier,
    }

    return update.definition.url
            .replace('{supplier}', parsedArgs.supplier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\SupplierController::update
* @see app/Http/Controllers/Stock/SupplierController.php:109
* @route '/stock/suppliers/{supplier}'
*/
update.put = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::update
* @see app/Http/Controllers/Stock/SupplierController.php:109
* @route '/stock/suppliers/{supplier}'
*/
const updateForm = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::update
* @see app/Http/Controllers/Stock/SupplierController.php:109
* @route '/stock/suppliers/{supplier}'
*/
updateForm.put = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Stock\SupplierController::pay
* @see app/Http/Controllers/Stock/SupplierController.php:64
* @route '/stock/suppliers/{supplier}/payments'
*/
export const pay = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

pay.definition = {
    methods: ["post"],
    url: '/stock/suppliers/{supplier}/payments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Stock\SupplierController::pay
* @see app/Http/Controllers/Stock/SupplierController.php:64
* @route '/stock/suppliers/{supplier}/payments'
*/
pay.url = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { supplier: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { supplier: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            supplier: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        supplier: typeof args.supplier === 'object'
        ? args.supplier.id
        : args.supplier,
    }

    return pay.definition.url
            .replace('{supplier}', parsedArgs.supplier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\SupplierController::pay
* @see app/Http/Controllers/Stock/SupplierController.php:64
* @route '/stock/suppliers/{supplier}/payments'
*/
pay.post = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::pay
* @see app/Http/Controllers/Stock/SupplierController.php:64
* @route '/stock/suppliers/{supplier}/payments'
*/
const payForm = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pay.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::pay
* @see app/Http/Controllers/Stock/SupplierController.php:64
* @route '/stock/suppliers/{supplier}/payments'
*/
payForm.post = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pay.url(args, options),
    method: 'post',
})

pay.form = payForm

/**
* @see \App\Http\Controllers\Stock\SupplierController::returnGoods
* @see app/Http/Controllers/Stock/SupplierController.php:80
* @route '/stock/suppliers/{supplier}/returns'
*/
export const returnGoods = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: returnGoods.url(args, options),
    method: 'post',
})

returnGoods.definition = {
    methods: ["post"],
    url: '/stock/suppliers/{supplier}/returns',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Stock\SupplierController::returnGoods
* @see app/Http/Controllers/Stock/SupplierController.php:80
* @route '/stock/suppliers/{supplier}/returns'
*/
returnGoods.url = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { supplier: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { supplier: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            supplier: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        supplier: typeof args.supplier === 'object'
        ? args.supplier.id
        : args.supplier,
    }

    return returnGoods.definition.url
            .replace('{supplier}', parsedArgs.supplier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\SupplierController::returnGoods
* @see app/Http/Controllers/Stock/SupplierController.php:80
* @route '/stock/suppliers/{supplier}/returns'
*/
returnGoods.post = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: returnGoods.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::returnGoods
* @see app/Http/Controllers/Stock/SupplierController.php:80
* @route '/stock/suppliers/{supplier}/returns'
*/
const returnGoodsForm = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: returnGoods.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::returnGoods
* @see app/Http/Controllers/Stock/SupplierController.php:80
* @route '/stock/suppliers/{supplier}/returns'
*/
returnGoodsForm.post = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: returnGoods.url(args, options),
    method: 'post',
})

returnGoods.form = returnGoodsForm

const SupplierController = { index, store, update, pay, returnGoods }

export default SupplierController