import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Stock\PurchaseController::index
* @see app/Http/Controllers/Stock/PurchaseController.php:26
* @route '/stock/purchases'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/stock/purchases',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Stock\PurchaseController::index
* @see app/Http/Controllers/Stock/PurchaseController.php:26
* @route '/stock/purchases'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\PurchaseController::index
* @see app/Http/Controllers/Stock/PurchaseController.php:26
* @route '/stock/purchases'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseController::index
* @see app/Http/Controllers/Stock/PurchaseController.php:26
* @route '/stock/purchases'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseController::index
* @see app/Http/Controllers/Stock/PurchaseController.php:26
* @route '/stock/purchases'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseController::index
* @see app/Http/Controllers/Stock/PurchaseController.php:26
* @route '/stock/purchases'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseController::index
* @see app/Http/Controllers/Stock/PurchaseController.php:26
* @route '/stock/purchases'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Stock\PurchaseController::store
* @see app/Http/Controllers/Stock/PurchaseController.php:69
* @route '/stock/purchases'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/stock/purchases',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Stock\PurchaseController::store
* @see app/Http/Controllers/Stock/PurchaseController.php:69
* @route '/stock/purchases'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\PurchaseController::store
* @see app/Http/Controllers/Stock/PurchaseController.php:69
* @route '/stock/purchases'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseController::store
* @see app/Http/Controllers/Stock/PurchaseController.php:69
* @route '/stock/purchases'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseController::store
* @see app/Http/Controllers/Stock/PurchaseController.php:69
* @route '/stock/purchases'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const PurchaseController = { index, store }

export default PurchaseController