import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Pos\PosController::index
* @see app/Http/Controllers/Pos/PosController.php:51
* @route '/pos'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/pos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Pos\PosController::index
* @see app/Http/Controllers/Pos/PosController.php:51
* @route '/pos'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::index
* @see app/Http/Controllers/Pos/PosController.php:51
* @route '/pos'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::index
* @see app/Http/Controllers/Pos/PosController.php:51
* @route '/pos'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Pos\PosController::index
* @see app/Http/Controllers/Pos/PosController.php:51
* @route '/pos'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::index
* @see app/Http/Controllers/Pos/PosController.php:51
* @route '/pos'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::index
* @see app/Http/Controllers/Pos/PosController.php:51
* @route '/pos'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Pos\PosController::store
* @see app/Http/Controllers/Pos/PosController.php:88
* @route '/pos/orders'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/pos/orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::store
* @see app/Http/Controllers/Pos/PosController.php:88
* @route '/pos/orders'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::store
* @see app/Http/Controllers/Pos/PosController.php:88
* @route '/pos/orders'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::store
* @see app/Http/Controllers/Pos/PosController.php:88
* @route '/pos/orders'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::store
* @see app/Http/Controllers/Pos/PosController.php:88
* @route '/pos/orders'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
export const show = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/pos/orders/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
show.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return show.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
show.get = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
show.head = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
const showForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
showForm.get = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
showForm.head = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Pos\PosController::addItem
* @see app/Http/Controllers/Pos/PosController.php:106
* @route '/pos/orders/{order}/items'
*/
export const addItem = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addItem.url(args, options),
    method: 'post',
})

addItem.definition = {
    methods: ["post"],
    url: '/pos/orders/{order}/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::addItem
* @see app/Http/Controllers/Pos/PosController.php:106
* @route '/pos/orders/{order}/items'
*/
addItem.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return addItem.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::addItem
* @see app/Http/Controllers/Pos/PosController.php:106
* @route '/pos/orders/{order}/items'
*/
addItem.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addItem.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::addItem
* @see app/Http/Controllers/Pos/PosController.php:106
* @route '/pos/orders/{order}/items'
*/
const addItemForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: addItem.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::addItem
* @see app/Http/Controllers/Pos/PosController.php:106
* @route '/pos/orders/{order}/items'
*/
addItemForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: addItem.url(args, options),
    method: 'post',
})

addItem.form = addItemForm

/**
* @see \App\Http\Controllers\Pos\PosController::sendKot
* @see app/Http/Controllers/Pos/PosController.php:149
* @route '/pos/orders/{order}/kot'
*/
export const sendKot = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendKot.url(args, options),
    method: 'post',
})

sendKot.definition = {
    methods: ["post"],
    url: '/pos/orders/{order}/kot',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::sendKot
* @see app/Http/Controllers/Pos/PosController.php:149
* @route '/pos/orders/{order}/kot'
*/
sendKot.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return sendKot.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::sendKot
* @see app/Http/Controllers/Pos/PosController.php:149
* @route '/pos/orders/{order}/kot'
*/
sendKot.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendKot.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::sendKot
* @see app/Http/Controllers/Pos/PosController.php:149
* @route '/pos/orders/{order}/kot'
*/
const sendKotForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: sendKot.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::sendKot
* @see app/Http/Controllers/Pos/PosController.php:149
* @route '/pos/orders/{order}/kot'
*/
sendKotForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: sendKot.url(args, options),
    method: 'post',
})

sendKot.form = sendKotForm

/**
* @see \App\Http\Controllers\Pos\PosController::move
* @see app/Http/Controllers/Pos/PosController.php:190
* @route '/pos/orders/{order}/move'
*/
export const move = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: move.url(args, options),
    method: 'post',
})

move.definition = {
    methods: ["post"],
    url: '/pos/orders/{order}/move',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::move
* @see app/Http/Controllers/Pos/PosController.php:190
* @route '/pos/orders/{order}/move'
*/
move.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return move.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::move
* @see app/Http/Controllers/Pos/PosController.php:190
* @route '/pos/orders/{order}/move'
*/
move.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: move.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::move
* @see app/Http/Controllers/Pos/PosController.php:190
* @route '/pos/orders/{order}/move'
*/
const moveForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: move.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::move
* @see app/Http/Controllers/Pos/PosController.php:190
* @route '/pos/orders/{order}/move'
*/
moveForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: move.url(args, options),
    method: 'post',
})

move.form = moveForm

/**
* @see \App\Http\Controllers\Pos\PosController::merge
* @see app/Http/Controllers/Pos/PosController.php:198
* @route '/pos/orders/{order}/merge'
*/
export const merge = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: merge.url(args, options),
    method: 'post',
})

merge.definition = {
    methods: ["post"],
    url: '/pos/orders/{order}/merge',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::merge
* @see app/Http/Controllers/Pos/PosController.php:198
* @route '/pos/orders/{order}/merge'
*/
merge.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return merge.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::merge
* @see app/Http/Controllers/Pos/PosController.php:198
* @route '/pos/orders/{order}/merge'
*/
merge.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: merge.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::merge
* @see app/Http/Controllers/Pos/PosController.php:198
* @route '/pos/orders/{order}/merge'
*/
const mergeForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: merge.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::merge
* @see app/Http/Controllers/Pos/PosController.php:198
* @route '/pos/orders/{order}/merge'
*/
mergeForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: merge.url(args, options),
    method: 'post',
})

merge.form = mergeForm

/**
* @see \App\Http\Controllers\Pos\PosController::cancel
* @see app/Http/Controllers/Pos/PosController.php:206
* @route '/pos/orders/{order}/cancel'
*/
export const cancel = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/pos/orders/{order}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::cancel
* @see app/Http/Controllers/Pos/PosController.php:206
* @route '/pos/orders/{order}/cancel'
*/
cancel.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return cancel.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::cancel
* @see app/Http/Controllers/Pos/PosController.php:206
* @route '/pos/orders/{order}/cancel'
*/
cancel.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::cancel
* @see app/Http/Controllers/Pos/PosController.php:206
* @route '/pos/orders/{order}/cancel'
*/
const cancelForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::cancel
* @see app/Http/Controllers/Pos/PosController.php:206
* @route '/pos/orders/{order}/cancel'
*/
cancelForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(args, options),
    method: 'post',
})

cancel.form = cancelForm

/**
* @see \App\Http\Controllers\Pos\PosController::updateItem
* @see app/Http/Controllers/Pos/PosController.php:123
* @route '/pos/order-items/{orderItem}'
*/
export const updateItem = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateItem.url(args, options),
    method: 'patch',
})

updateItem.definition = {
    methods: ["patch"],
    url: '/pos/order-items/{orderItem}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Pos\PosController::updateItem
* @see app/Http/Controllers/Pos/PosController.php:123
* @route '/pos/order-items/{orderItem}'
*/
updateItem.url = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { orderItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            orderItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        orderItem: typeof args.orderItem === 'object'
        ? args.orderItem.id
        : args.orderItem,
    }

    return updateItem.definition.url
            .replace('{orderItem}', parsedArgs.orderItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::updateItem
* @see app/Http/Controllers/Pos/PosController.php:123
* @route '/pos/order-items/{orderItem}'
*/
updateItem.patch = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateItem.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Pos\PosController::updateItem
* @see app/Http/Controllers/Pos/PosController.php:123
* @route '/pos/order-items/{orderItem}'
*/
const updateItemForm = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::updateItem
* @see app/Http/Controllers/Pos/PosController.php:123
* @route '/pos/order-items/{orderItem}'
*/
updateItemForm.patch = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateItem.form = updateItemForm

/**
* @see \App\Http\Controllers\Pos\PosController::removeItem
* @see app/Http/Controllers/Pos/PosController.php:138
* @route '/pos/order-items/{orderItem}'
*/
export const removeItem = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeItem.url(args, options),
    method: 'delete',
})

removeItem.definition = {
    methods: ["delete"],
    url: '/pos/order-items/{orderItem}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Pos\PosController::removeItem
* @see app/Http/Controllers/Pos/PosController.php:138
* @route '/pos/order-items/{orderItem}'
*/
removeItem.url = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { orderItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            orderItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        orderItem: typeof args.orderItem === 'object'
        ? args.orderItem.id
        : args.orderItem,
    }

    return removeItem.definition.url
            .replace('{orderItem}', parsedArgs.orderItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::removeItem
* @see app/Http/Controllers/Pos/PosController.php:138
* @route '/pos/order-items/{orderItem}'
*/
removeItem.delete = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeItem.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Pos\PosController::removeItem
* @see app/Http/Controllers/Pos/PosController.php:138
* @route '/pos/order-items/{orderItem}'
*/
const removeItemForm = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::removeItem
* @see app/Http/Controllers/Pos/PosController.php:138
* @route '/pos/order-items/{orderItem}'
*/
removeItemForm.delete = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: removeItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

removeItem.form = removeItemForm

/**
* @see \App\Http\Controllers\Pos\PosController::voidItem
* @see app/Http/Controllers/Pos/PosController.php:159
* @route '/pos/order-items/{orderItem}/void'
*/
export const voidItem = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: voidItem.url(args, options),
    method: 'post',
})

voidItem.definition = {
    methods: ["post"],
    url: '/pos/order-items/{orderItem}/void',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::voidItem
* @see app/Http/Controllers/Pos/PosController.php:159
* @route '/pos/order-items/{orderItem}/void'
*/
voidItem.url = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { orderItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            orderItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        orderItem: typeof args.orderItem === 'object'
        ? args.orderItem.id
        : args.orderItem,
    }

    return voidItem.definition.url
            .replace('{orderItem}', parsedArgs.orderItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::voidItem
* @see app/Http/Controllers/Pos/PosController.php:159
* @route '/pos/order-items/{orderItem}/void'
*/
voidItem.post = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: voidItem.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::voidItem
* @see app/Http/Controllers/Pos/PosController.php:159
* @route '/pos/order-items/{orderItem}/void'
*/
const voidItemForm = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: voidItem.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::voidItem
* @see app/Http/Controllers/Pos/PosController.php:159
* @route '/pos/order-items/{orderItem}/void'
*/
voidItemForm.post = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: voidItem.url(args, options),
    method: 'post',
})

voidItem.form = voidItemForm

/**
* @see \App\Http\Controllers\Pos\PosController::markServed
* @see app/Http/Controllers/Pos/PosController.php:176
* @route '/pos/order-items/{orderItem}/served'
*/
export const markServed = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markServed.url(args, options),
    method: 'patch',
})

markServed.definition = {
    methods: ["patch"],
    url: '/pos/order-items/{orderItem}/served',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Pos\PosController::markServed
* @see app/Http/Controllers/Pos/PosController.php:176
* @route '/pos/order-items/{orderItem}/served'
*/
markServed.url = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { orderItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            orderItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        orderItem: typeof args.orderItem === 'object'
        ? args.orderItem.id
        : args.orderItem,
    }

    return markServed.definition.url
            .replace('{orderItem}', parsedArgs.orderItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::markServed
* @see app/Http/Controllers/Pos/PosController.php:176
* @route '/pos/order-items/{orderItem}/served'
*/
markServed.patch = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markServed.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Pos\PosController::markServed
* @see app/Http/Controllers/Pos/PosController.php:176
* @route '/pos/order-items/{orderItem}/served'
*/
const markServedForm = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markServed.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::markServed
* @see app/Http/Controllers/Pos/PosController.php:176
* @route '/pos/order-items/{orderItem}/served'
*/
markServedForm.patch = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markServed.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

markServed.form = markServedForm

/**
* @see \App\Http\Controllers\Pos\PosController::printKot
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
export const printKot = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printKot.url(args, options),
    method: 'get',
})

printKot.definition = {
    methods: ["get","head"],
    url: '/pos/kots/{kot}/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Pos\PosController::printKot
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
printKot.url = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kot: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { kot: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            kot: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kot: typeof args.kot === 'object'
        ? args.kot.id
        : args.kot,
    }

    return printKot.definition.url
            .replace('{kot}', parsedArgs.kot.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::printKot
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
printKot.get = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printKot.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::printKot
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
printKot.head = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printKot.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Pos\PosController::printKot
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
const printKotForm = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printKot.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::printKot
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
printKotForm.get = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printKot.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::printKot
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
printKotForm.head = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printKot.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

printKot.form = printKotForm

const PosController = { index, store, show, addItem, sendKot, move, merge, cancel, updateItem, removeItem, voidItem, markServed, printKot }

export default PosController