import PosController from './PosController'

const Pos = {
    PosController: Object.assign(PosController, PosController),
}

export default Pos