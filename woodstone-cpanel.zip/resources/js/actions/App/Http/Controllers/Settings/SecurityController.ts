import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\SecurityController::edit
* @see app/Http/Controllers/Settings/SecurityController.php:25
* @route '/settings/security'
*/
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/security',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\SecurityController::edit
* @see app/Http/Controllers/Settings/SecurityController.php:25
* @route '/settings/security'
*/
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SecurityController::edit
* @see app/Http/Controllers/Settings/SecurityController.php:25
* @route '/settings/security'
*/
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\SecurityController::edit
* @see app/Http/Controllers/Settings/SecurityController.php:25
* @route '/settings/security'
*/
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Settings\SecurityController::edit
* @see app/Http/Controllers/Settings/SecurityController.php:25
* @route '/settings/security'
*/
const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\SecurityController::edit
* @see app/Http/Controllers/Settings/SecurityController.php:25
* @route '/settings/security'
*/
editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Settings\SecurityController::edit
* @see app/Http/Controllers/Settings/SecurityController.php:25
* @route '/settings/security'
*/
editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Settings\SecurityController::update
* @see app/Http/Controllers/Settings/SecurityController.php:71
* @route '/settings/password'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/password',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Settings\SecurityController::update
* @see app/Http/Controllers/Settings/SecurityController.php:71
* @route '/settings/password'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SecurityController::update
* @see app/Http/Controllers/Settings/SecurityController.php:71
* @route '/settings/password'
*/
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Settings\SecurityController::update
* @see app/Http/Controllers/Settings/SecurityController.php:71
* @route '/settings/password'
*/
const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\SecurityController::update
* @see app/Http/Controllers/Settings/SecurityController.php:71
* @route '/settings/password'
*/
updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Settings\SecurityController::updatePin
* @see app/Http/Controllers/Settings/SecurityController.php:89
* @route '/settings/pin'
*/
export const updatePin = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePin.url(options),
    method: 'put',
})

updatePin.definition = {
    methods: ["put"],
    url: '/settings/pin',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Settings\SecurityController::updatePin
* @see app/Http/Controllers/Settings/SecurityController.php:89
* @route '/settings/pin'
*/
updatePin.url = (options?: RouteQueryOptions) => {
    return updatePin.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SecurityController::updatePin
* @see app/Http/Controllers/Settings/SecurityController.php:89
* @route '/settings/pin'
*/
updatePin.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePin.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Settings\SecurityController::updatePin
* @see app/Http/Controllers/Settings/SecurityController.php:89
* @route '/settings/pin'
*/
const updatePinForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updatePin.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\SecurityController::updatePin
* @see app/Http/Controllers/Settings/SecurityController.php:89
* @route '/settings/pin'
*/
updatePinForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updatePin.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updatePin.form = updatePinForm

/**
* @see \App\Http\Controllers\Settings\SecurityController::destroyPin
* @see app/Http/Controllers/Settings/SecurityController.php:110
* @route '/settings/pin'
*/
export const destroyPin = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyPin.url(options),
    method: 'delete',
})

destroyPin.definition = {
    methods: ["delete"],
    url: '/settings/pin',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Settings\SecurityController::destroyPin
* @see app/Http/Controllers/Settings/SecurityController.php:110
* @route '/settings/pin'
*/
destroyPin.url = (options?: RouteQueryOptions) => {
    return destroyPin.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SecurityController::destroyPin
* @see app/Http/Controllers/Settings/SecurityController.php:110
* @route '/settings/pin'
*/
destroyPin.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyPin.url(options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Settings\SecurityController::destroyPin
* @see app/Http/Controllers/Settings/SecurityController.php:110
* @route '/settings/pin'
*/
const destroyPinForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyPin.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Settings\SecurityController::destroyPin
* @see app/Http/Controllers/Settings/SecurityController.php:110
* @route '/settings/pin'
*/
destroyPinForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyPin.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyPin.form = destroyPinForm

const SecurityController = { edit, update, updatePin, destroyPin }

export default SecurityController