import BillController from './BillController'

const Billing = {
    BillController: Object.assign(BillController, BillController),
}

export default Billing