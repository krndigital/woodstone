import GuestController from './GuestController'
import ServiceCallController from './ServiceCallController'

const Guest = {
    GuestController: Object.assign(GuestController, GuestController),
    ServiceCallController: Object.assign(ServiceCallController, ServiceCallController),
}

export default Guest