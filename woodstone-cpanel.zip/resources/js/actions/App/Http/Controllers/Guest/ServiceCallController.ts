import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Guest\ServiceCallController::pending
* @see app/Http/Controllers/Guest/ServiceCallController.php:30
* @route '/calls/pending'
*/
export const pending = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pending.url(options),
    method: 'get',
})

pending.definition = {
    methods: ["get","head"],
    url: '/calls/pending',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::pending
* @see app/Http/Controllers/Guest/ServiceCallController.php:30
* @route '/calls/pending'
*/
pending.url = (options?: RouteQueryOptions) => {
    return pending.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::pending
* @see app/Http/Controllers/Guest/ServiceCallController.php:30
* @route '/calls/pending'
*/
pending.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pending.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::pending
* @see app/Http/Controllers/Guest/ServiceCallController.php:30
* @route '/calls/pending'
*/
pending.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pending.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::pending
* @see app/Http/Controllers/Guest/ServiceCallController.php:30
* @route '/calls/pending'
*/
const pendingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pending.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::pending
* @see app/Http/Controllers/Guest/ServiceCallController.php:30
* @route '/calls/pending'
*/
pendingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pending.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::pending
* @see app/Http/Controllers/Guest/ServiceCallController.php:30
* @route '/calls/pending'
*/
pendingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pending.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

pending.form = pendingForm

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::accept
* @see app/Http/Controllers/Guest/ServiceCallController.php:54
* @route '/calls/{call}/accept'
*/
export const accept = (args: { call: number | { id: number } } | [call: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: accept.url(args, options),
    method: 'patch',
})

accept.definition = {
    methods: ["patch"],
    url: '/calls/{call}/accept',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::accept
* @see app/Http/Controllers/Guest/ServiceCallController.php:54
* @route '/calls/{call}/accept'
*/
accept.url = (args: { call: number | { id: number } } | [call: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { call: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { call: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            call: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        call: typeof args.call === 'object'
        ? args.call.id
        : args.call,
    }

    return accept.definition.url
            .replace('{call}', parsedArgs.call.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::accept
* @see app/Http/Controllers/Guest/ServiceCallController.php:54
* @route '/calls/{call}/accept'
*/
accept.patch = (args: { call: number | { id: number } } | [call: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: accept.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::accept
* @see app/Http/Controllers/Guest/ServiceCallController.php:54
* @route '/calls/{call}/accept'
*/
const acceptForm = (args: { call: number | { id: number } } | [call: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: accept.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::accept
* @see app/Http/Controllers/Guest/ServiceCallController.php:54
* @route '/calls/{call}/accept'
*/
acceptForm.patch = (args: { call: number | { id: number } } | [call: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: accept.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

accept.form = acceptForm

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::done
* @see app/Http/Controllers/Guest/ServiceCallController.php:66
* @route '/calls/{call}/done'
*/
export const done = (args: { call: number | { id: number } } | [call: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: done.url(args, options),
    method: 'patch',
})

done.definition = {
    methods: ["patch"],
    url: '/calls/{call}/done',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::done
* @see app/Http/Controllers/Guest/ServiceCallController.php:66
* @route '/calls/{call}/done'
*/
done.url = (args: { call: number | { id: number } } | [call: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { call: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { call: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            call: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        call: typeof args.call === 'object'
        ? args.call.id
        : args.call,
    }

    return done.definition.url
            .replace('{call}', parsedArgs.call.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::done
* @see app/Http/Controllers/Guest/ServiceCallController.php:66
* @route '/calls/{call}/done'
*/
done.patch = (args: { call: number | { id: number } } | [call: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: done.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::done
* @see app/Http/Controllers/Guest/ServiceCallController.php:66
* @route '/calls/{call}/done'
*/
const doneForm = (args: { call: number | { id: number } } | [call: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: done.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::done
* @see app/Http/Controllers/Guest/ServiceCallController.php:66
* @route '/calls/{call}/done'
*/
doneForm.patch = (args: { call: number | { id: number } } | [call: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: done.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

done.form = doneForm

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::ping
* @see app/Http/Controllers/Guest/ServiceCallController.php:90
* @route '/calls/ping'
*/
export const ping = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ping.url(options),
    method: 'post',
})

ping.definition = {
    methods: ["post"],
    url: '/calls/ping',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::ping
* @see app/Http/Controllers/Guest/ServiceCallController.php:90
* @route '/calls/ping'
*/
ping.url = (options?: RouteQueryOptions) => {
    return ping.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::ping
* @see app/Http/Controllers/Guest/ServiceCallController.php:90
* @route '/calls/ping'
*/
ping.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ping.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::ping
* @see app/Http/Controllers/Guest/ServiceCallController.php:90
* @route '/calls/ping'
*/
const pingForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: ping.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Guest\ServiceCallController::ping
* @see app/Http/Controllers/Guest/ServiceCallController.php:90
* @route '/calls/ping'
*/
pingForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: ping.url(options),
    method: 'post',
})

ping.form = pingForm

const ServiceCallController = { pending, accept, done, ping }

export default ServiceCallController