import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Guest\GuestController::show
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
export const show = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/t/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Guest\GuestController::show
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
show.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return show.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Guest\GuestController::show
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
show.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::show
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
show.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::show
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
const showForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::show
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
showForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::show
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
showForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
export const status = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(args, options),
    method: 'get',
})

status.definition = {
    methods: ["get","head"],
    url: '/t/{token}/calls/{publicId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
status.url = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            token: args[0],
            publicId: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
        publicId: args.publicId,
    }

    return status.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace('{publicId}', parsedArgs.publicId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
status.get = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
status.head = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
const statusForm = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
statusForm.get = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
statusForm.head = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

status.form = statusForm

/**
* @see \App\Http\Controllers\Guest\GuestController::call
* @see app/Http/Controllers/Guest/GuestController.php:51
* @route '/t/{token}/calls'
*/
export const call = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: call.url(args, options),
    method: 'post',
})

call.definition = {
    methods: ["post"],
    url: '/t/{token}/calls',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Guest\GuestController::call
* @see app/Http/Controllers/Guest/GuestController.php:51
* @route '/t/{token}/calls'
*/
call.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return call.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Guest\GuestController::call
* @see app/Http/Controllers/Guest/GuestController.php:51
* @route '/t/{token}/calls'
*/
call.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: call.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::call
* @see app/Http/Controllers/Guest/GuestController.php:51
* @route '/t/{token}/calls'
*/
const callForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: call.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::call
* @see app/Http/Controllers/Guest/GuestController.php:51
* @route '/t/{token}/calls'
*/
callForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: call.url(args, options),
    method: 'post',
})

call.form = callForm

const GuestController = { show, status, call }

export default GuestController