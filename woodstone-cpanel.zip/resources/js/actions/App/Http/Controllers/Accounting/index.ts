import AccountingController from './AccountingController'

const Accounting = {
    AccountingController: Object.assign(AccountingController, AccountingController),
}

export default Accounting