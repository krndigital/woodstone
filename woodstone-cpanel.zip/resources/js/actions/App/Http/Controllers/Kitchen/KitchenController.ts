import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/kitchen',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:72
* @route '/kitchen/items/{orderItem}/bump'
*/
export const bump = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: bump.url(args, options),
    method: 'patch',
})

bump.definition = {
    methods: ["patch"],
    url: '/kitchen/items/{orderItem}/bump',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:72
* @route '/kitchen/items/{orderItem}/bump'
*/
bump.url = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { orderItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            orderItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        orderItem: typeof args.orderItem === 'object'
        ? args.orderItem.id
        : args.orderItem,
    }

    return bump.definition.url
            .replace('{orderItem}', parsedArgs.orderItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:72
* @route '/kitchen/items/{orderItem}/bump'
*/
bump.patch = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: bump.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:72
* @route '/kitchen/items/{orderItem}/bump'
*/
const bumpForm = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: bump.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:72
* @route '/kitchen/items/{orderItem}/bump'
*/
bumpForm.patch = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: bump.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

bump.form = bumpForm

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bumpKot
* @see app/Http/Controllers/Kitchen/KitchenController.php:82
* @route '/kitchen/kots/{kot}/bump'
*/
export const bumpKot = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: bumpKot.url(args, options),
    method: 'patch',
})

bumpKot.definition = {
    methods: ["patch"],
    url: '/kitchen/kots/{kot}/bump',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bumpKot
* @see app/Http/Controllers/Kitchen/KitchenController.php:82
* @route '/kitchen/kots/{kot}/bump'
*/
bumpKot.url = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kot: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { kot: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            kot: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kot: typeof args.kot === 'object'
        ? args.kot.id
        : args.kot,
    }

    return bumpKot.definition.url
            .replace('{kot}', parsedArgs.kot.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bumpKot
* @see app/Http/Controllers/Kitchen/KitchenController.php:82
* @route '/kitchen/kots/{kot}/bump'
*/
bumpKot.patch = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: bumpKot.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bumpKot
* @see app/Http/Controllers/Kitchen/KitchenController.php:82
* @route '/kitchen/kots/{kot}/bump'
*/
const bumpKotForm = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: bumpKot.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bumpKot
* @see app/Http/Controllers/Kitchen/KitchenController.php:82
* @route '/kitchen/kots/{kot}/bump'
*/
bumpKotForm.patch = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: bumpKot.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

bumpKot.form = bumpKotForm

const KitchenController = { index, bump, bumpKot }

export default KitchenController