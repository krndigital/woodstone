import KitchenController from './KitchenController'

const Kitchen = {
    KitchenController: Object.assign(KitchenController, KitchenController),
}

export default Kitchen