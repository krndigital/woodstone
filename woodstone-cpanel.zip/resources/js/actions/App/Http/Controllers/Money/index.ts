import CashBookController from './CashBookController'
import ExpenseController from './ExpenseController'
import DayController from './DayController'

const Money = {
    CashBookController: Object.assign(CashBookController, CashBookController),
    ExpenseController: Object.assign(ExpenseController, ExpenseController),
    DayController: Object.assign(DayController, DayController),
}

export default Money