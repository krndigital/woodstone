import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Money\CashBookController::index
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/money/cash-book',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Money\CashBookController::index
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\CashBookController::index
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::index
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::index
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::index
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::index
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Money\CashBookController::manual
* @see app/Http/Controllers/Money/CashBookController.php:68
* @route '/money/cash-book/entries'
*/
export const manual = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: manual.url(options),
    method: 'post',
})

manual.definition = {
    methods: ["post"],
    url: '/money/cash-book/entries',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Money\CashBookController::manual
* @see app/Http/Controllers/Money/CashBookController.php:68
* @route '/money/cash-book/entries'
*/
manual.url = (options?: RouteQueryOptions) => {
    return manual.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\CashBookController::manual
* @see app/Http/Controllers/Money/CashBookController.php:68
* @route '/money/cash-book/entries'
*/
manual.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: manual.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::manual
* @see app/Http/Controllers/Money/CashBookController.php:68
* @route '/money/cash-book/entries'
*/
const manualForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: manual.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::manual
* @see app/Http/Controllers/Money/CashBookController.php:68
* @route '/money/cash-book/entries'
*/
manualForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: manual.url(options),
    method: 'post',
})

manual.form = manualForm

/**
* @see \App\Http\Controllers\Money\CashBookController::transfer
* @see app/Http/Controllers/Money/CashBookController.php:83
* @route '/money/cash-book/transfers'
*/
export const transfer = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: transfer.url(options),
    method: 'post',
})

transfer.definition = {
    methods: ["post"],
    url: '/money/cash-book/transfers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Money\CashBookController::transfer
* @see app/Http/Controllers/Money/CashBookController.php:83
* @route '/money/cash-book/transfers'
*/
transfer.url = (options?: RouteQueryOptions) => {
    return transfer.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\CashBookController::transfer
* @see app/Http/Controllers/Money/CashBookController.php:83
* @route '/money/cash-book/transfers'
*/
transfer.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: transfer.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::transfer
* @see app/Http/Controllers/Money/CashBookController.php:83
* @route '/money/cash-book/transfers'
*/
const transferForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: transfer.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::transfer
* @see app/Http/Controllers/Money/CashBookController.php:83
* @route '/money/cash-book/transfers'
*/
transferForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: transfer.url(options),
    method: 'post',
})

transfer.form = transferForm

const CashBookController = { index, manual, transfer }

export default CashBookController