import { createInertiaApp } from '@inertiajs/vue3';
import { initializeTheme } from '@/composables/useAppearance';
import AppLayout from '@/layouts/AppLayout.vue';
import AuthLayout from '@/layouts/AuthLayout.vue';
import SettingsLayout from '@/layouts/settings/Layout.vue';
import { initializeFlashToast } from '@/lib/flashToast';

const appName = import.meta.env.VITE_APP_NAME || 'Laravel';

void createInertiaApp({
    title: (title) => (title ? `${title} - ${appName}` : appName),
    layout: (name) => {
        switch (true) {
            case name.startsWith('auth/'):
                return AuthLayout;
            case name.startsWith('guest/'):
                return null;
            case name.startsWith('settings/'):
                return [AppLayout, SettingsLayout];
            default:
                return AppLayout;
        }
    },
    withApp: (app) => {
        app.directive('focus', {
            mounted: (el: HTMLElement, shouldFocus) => {
                if (shouldFocus.value !== false) {
                    el.focus();
                }
            },
        });
    },
    progress: {
        color: '#4B5563',
    },
});

// This will set light / dark mode on page load...
initializeTheme();

// This will listen for flash toast data from the server...
initializeFlashToast();

// Hover hint for icon buttons: show their aria-label as a tooltip.
const addTitles = (root: ParentNode): void => {
    root.querySelectorAll<HTMLElement>(
        'button[aria-label]:not([title]), a[aria-label]:not([title])',
    ).forEach((el) => {
        el.title = el.getAttribute('aria-label') ?? '';
    });
};
let titlesQueued = false;
new MutationObserver(() => {
    if (titlesQueued) return;
    titlesQueued = true;
    requestAnimationFrame(() => {
        titlesQueued = false;
        addTitles(document);
    });
}).observe(document.body, {
    childList: true,
    subtree: true,
});
addTitles(document);

// Installable on phones and tablets (waiter app). No offline caching.
if (
    'serviceWorker' in navigator &&
    (location.protocol === 'https:' || location.hostname === 'localhost')
) {
    window.addEventListener('load', () => {
        void navigator.serviceWorker.register('/sw.js');
    });
}
