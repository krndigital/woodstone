import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import bills from './bills'
/**
* @see \App\Http\Controllers\Billing\BillController::index
* @see app/Http/Controllers/Billing/BillController.php:38
* @route '/billing'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/billing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Billing\BillController::index
* @see app/Http/Controllers/Billing/BillController.php:38
* @route '/billing'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Billing\BillController::index
* @see app/Http/Controllers/Billing/BillController.php:38
* @route '/billing'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Billing\BillController::index
* @see app/Http/Controllers/Billing/BillController.php:38
* @route '/billing'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Billing\BillController::index
* @see app/Http/Controllers/Billing/BillController.php:38
* @route '/billing'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Billing\BillController::index
* @see app/Http/Controllers/Billing/BillController.php:38
* @route '/billing'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Billing\BillController::index
* @see app/Http/Controllers/Billing/BillController.php:38
* @route '/billing'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Billing\BillController::checkout
* @see app/Http/Controllers/Billing/BillController.php:101
* @route '/billing/orders/{order}'
*/
export const checkout = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkout.url(args, options),
    method: 'get',
})

checkout.definition = {
    methods: ["get","head"],
    url: '/billing/orders/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Billing\BillController::checkout
* @see app/Http/Controllers/Billing/BillController.php:101
* @route '/billing/orders/{order}'
*/
checkout.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return checkout.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Billing\BillController::checkout
* @see app/Http/Controllers/Billing/BillController.php:101
* @route '/billing/orders/{order}'
*/
checkout.get = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkout.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Billing\BillController::checkout
* @see app/Http/Controllers/Billing/BillController.php:101
* @route '/billing/orders/{order}'
*/
checkout.head = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: checkout.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Billing\BillController::checkout
* @see app/Http/Controllers/Billing/BillController.php:101
* @route '/billing/orders/{order}'
*/
const checkoutForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: checkout.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Billing\BillController::checkout
* @see app/Http/Controllers/Billing/BillController.php:101
* @route '/billing/orders/{order}'
*/
checkoutForm.get = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: checkout.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Billing\BillController::checkout
* @see app/Http/Controllers/Billing/BillController.php:101
* @route '/billing/orders/{order}'
*/
checkoutForm.head = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: checkout.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

checkout.form = checkoutForm

/**
* @see \App\Http\Controllers\Billing\BillController::settle
* @see app/Http/Controllers/Billing/BillController.php:141
* @route '/billing/orders/{order}/settle'
*/
export const settle = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: settle.url(args, options),
    method: 'post',
})

settle.definition = {
    methods: ["post"],
    url: '/billing/orders/{order}/settle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Billing\BillController::settle
* @see app/Http/Controllers/Billing/BillController.php:141
* @route '/billing/orders/{order}/settle'
*/
settle.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return settle.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Billing\BillController::settle
* @see app/Http/Controllers/Billing/BillController.php:141
* @route '/billing/orders/{order}/settle'
*/
settle.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: settle.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Billing\BillController::settle
* @see app/Http/Controllers/Billing/BillController.php:141
* @route '/billing/orders/{order}/settle'
*/
const settleForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: settle.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Billing\BillController::settle
* @see app/Http/Controllers/Billing/BillController.php:141
* @route '/billing/orders/{order}/settle'
*/
settleForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: settle.url(args, options),
    method: 'post',
})

settle.form = settleForm

const billing = {
    index: Object.assign(index, index),
    checkout: Object.assign(checkout, checkout),
    settle: Object.assign(settle, settle),
    bills: Object.assign(bills, bills),
}

export default billing