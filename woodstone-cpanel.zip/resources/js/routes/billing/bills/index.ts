import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Billing\BillController::print
* @see app/Http/Controllers/Billing/BillController.php:173
* @route '/billing/bills/{bill}/print'
*/
export const print = (args: { bill: number | { id: number } } | [bill: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

print.definition = {
    methods: ["get","head"],
    url: '/billing/bills/{bill}/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Billing\BillController::print
* @see app/Http/Controllers/Billing/BillController.php:173
* @route '/billing/bills/{bill}/print'
*/
print.url = (args: { bill: number | { id: number } } | [bill: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bill: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { bill: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            bill: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        bill: typeof args.bill === 'object'
        ? args.bill.id
        : args.bill,
    }

    return print.definition.url
            .replace('{bill}', parsedArgs.bill.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Billing\BillController::print
* @see app/Http/Controllers/Billing/BillController.php:173
* @route '/billing/bills/{bill}/print'
*/
print.get = (args: { bill: number | { id: number } } | [bill: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Billing\BillController::print
* @see app/Http/Controllers/Billing/BillController.php:173
* @route '/billing/bills/{bill}/print'
*/
print.head = (args: { bill: number | { id: number } } | [bill: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: print.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Billing\BillController::print
* @see app/Http/Controllers/Billing/BillController.php:173
* @route '/billing/bills/{bill}/print'
*/
const printForm = (args: { bill: number | { id: number } } | [bill: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Billing\BillController::print
* @see app/Http/Controllers/Billing/BillController.php:173
* @route '/billing/bills/{bill}/print'
*/
printForm.get = (args: { bill: number | { id: number } } | [bill: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Billing\BillController::print
* @see app/Http/Controllers/Billing/BillController.php:173
* @route '/billing/bills/{bill}/print'
*/
printForm.head = (args: { bill: number | { id: number } } | [bill: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

print.form = printForm

/**
* @see \App\Http\Controllers\Billing\BillController::returnMethod
* @see app/Http/Controllers/Billing/BillController.php:76
* @route '/billing/bills/{bill}/return'
*/
export const returnMethod = (args: { bill: number | { id: number } } | [bill: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: returnMethod.url(args, options),
    method: 'post',
})

returnMethod.definition = {
    methods: ["post"],
    url: '/billing/bills/{bill}/return',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Billing\BillController::returnMethod
* @see app/Http/Controllers/Billing/BillController.php:76
* @route '/billing/bills/{bill}/return'
*/
returnMethod.url = (args: { bill: number | { id: number } } | [bill: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bill: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { bill: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            bill: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        bill: typeof args.bill === 'object'
        ? args.bill.id
        : args.bill,
    }

    return returnMethod.definition.url
            .replace('{bill}', parsedArgs.bill.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Billing\BillController::returnMethod
* @see app/Http/Controllers/Billing/BillController.php:76
* @route '/billing/bills/{bill}/return'
*/
returnMethod.post = (args: { bill: number | { id: number } } | [bill: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: returnMethod.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Billing\BillController::returnMethod
* @see app/Http/Controllers/Billing/BillController.php:76
* @route '/billing/bills/{bill}/return'
*/
const returnMethodForm = (args: { bill: number | { id: number } } | [bill: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: returnMethod.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Billing\BillController::returnMethod
* @see app/Http/Controllers/Billing/BillController.php:76
* @route '/billing/bills/{bill}/return'
*/
returnMethodForm.post = (args: { bill: number | { id: number } } | [bill: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: returnMethod.url(args, options),
    method: 'post',
})

returnMethod.form = returnMethodForm

const bills = {
    print: Object.assign(print, print),
    return: Object.assign(returnMethod, returnMethod),
}

export default bills