import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import items from './items'
import kots from './kots'
/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/kitchen',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::index
* @see app/Http/Controllers/Kitchen/KitchenController.php:27
* @route '/kitchen'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const kitchen = {
    index: Object.assign(index, index),
    items: Object.assign(items, items),
    kots: Object.assign(kots, kots),
}

export default kitchen