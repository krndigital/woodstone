import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:72
* @route '/kitchen/items/{orderItem}/bump'
*/
export const bump = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: bump.url(args, options),
    method: 'patch',
})

bump.definition = {
    methods: ["patch"],
    url: '/kitchen/items/{orderItem}/bump',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:72
* @route '/kitchen/items/{orderItem}/bump'
*/
bump.url = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { orderItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            orderItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        orderItem: typeof args.orderItem === 'object'
        ? args.orderItem.id
        : args.orderItem,
    }

    return bump.definition.url
            .replace('{orderItem}', parsedArgs.orderItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:72
* @route '/kitchen/items/{orderItem}/bump'
*/
bump.patch = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: bump.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:72
* @route '/kitchen/items/{orderItem}/bump'
*/
const bumpForm = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: bump.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:72
* @route '/kitchen/items/{orderItem}/bump'
*/
bumpForm.patch = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: bump.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

bump.form = bumpForm

const items = {
    bump: Object.assign(bump, bump),
}

export default items