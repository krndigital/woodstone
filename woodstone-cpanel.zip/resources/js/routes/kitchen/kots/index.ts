import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:82
* @route '/kitchen/kots/{kot}/bump'
*/
export const bump = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: bump.url(args, options),
    method: 'patch',
})

bump.definition = {
    methods: ["patch"],
    url: '/kitchen/kots/{kot}/bump',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:82
* @route '/kitchen/kots/{kot}/bump'
*/
bump.url = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kot: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { kot: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            kot: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kot: typeof args.kot === 'object'
        ? args.kot.id
        : args.kot,
    }

    return bump.definition.url
            .replace('{kot}', parsedArgs.kot.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:82
* @route '/kitchen/kots/{kot}/bump'
*/
bump.patch = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: bump.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:82
* @route '/kitchen/kots/{kot}/bump'
*/
const bumpForm = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: bump.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kitchen\KitchenController::bump
* @see app/Http/Controllers/Kitchen/KitchenController.php:82
* @route '/kitchen/kots/{kot}/bump'
*/
bumpForm.patch = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: bump.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

bump.form = bumpForm

const kots = {
    bump: Object.assign(bump, bump),
}

export default kots