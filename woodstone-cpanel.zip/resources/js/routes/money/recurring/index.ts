import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Money\ExpenseController::store
* @see app/Http/Controllers/Money/ExpenseController.php:114
* @route '/money/recurring-expenses'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/money/recurring-expenses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Money\ExpenseController::store
* @see app/Http/Controllers/Money/ExpenseController.php:114
* @route '/money/recurring-expenses'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\ExpenseController::store
* @see app/Http/Controllers/Money/ExpenseController.php:114
* @route '/money/recurring-expenses'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::store
* @see app/Http/Controllers/Money/ExpenseController.php:114
* @route '/money/recurring-expenses'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::store
* @see app/Http/Controllers/Money/ExpenseController.php:114
* @route '/money/recurring-expenses'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Money\ExpenseController::update
* @see app/Http/Controllers/Money/ExpenseController.php:123
* @route '/money/recurring-expenses/{recurringExpense}'
*/
export const update = (args: { recurringExpense: number | { id: number } } | [recurringExpense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/money/recurring-expenses/{recurringExpense}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Money\ExpenseController::update
* @see app/Http/Controllers/Money/ExpenseController.php:123
* @route '/money/recurring-expenses/{recurringExpense}'
*/
update.url = (args: { recurringExpense: number | { id: number } } | [recurringExpense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { recurringExpense: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { recurringExpense: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            recurringExpense: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        recurringExpense: typeof args.recurringExpense === 'object'
        ? args.recurringExpense.id
        : args.recurringExpense,
    }

    return update.definition.url
            .replace('{recurringExpense}', parsedArgs.recurringExpense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\ExpenseController::update
* @see app/Http/Controllers/Money/ExpenseController.php:123
* @route '/money/recurring-expenses/{recurringExpense}'
*/
update.put = (args: { recurringExpense: number | { id: number } } | [recurringExpense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::update
* @see app/Http/Controllers/Money/ExpenseController.php:123
* @route '/money/recurring-expenses/{recurringExpense}'
*/
const updateForm = (args: { recurringExpense: number | { id: number } } | [recurringExpense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::update
* @see app/Http/Controllers/Money/ExpenseController.php:123
* @route '/money/recurring-expenses/{recurringExpense}'
*/
updateForm.put = (args: { recurringExpense: number | { id: number } } | [recurringExpense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const recurring = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
}

export default recurring