import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import cashBookC51ebc from './cash-book'
import expenses from './expenses'
import recurring from './recurring'
import dayB024b4 from './day'
/**
* @see \App\Http\Controllers\Money\CashBookController::cashBook
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
export const cashBook = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cashBook.url(options),
    method: 'get',
})

cashBook.definition = {
    methods: ["get","head"],
    url: '/money/cash-book',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Money\CashBookController::cashBook
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
cashBook.url = (options?: RouteQueryOptions) => {
    return cashBook.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\CashBookController::cashBook
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
cashBook.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cashBook.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::cashBook
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
cashBook.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cashBook.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::cashBook
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
const cashBookForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cashBook.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::cashBook
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
cashBookForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cashBook.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::cashBook
* @see app/Http/Controllers/Money/CashBookController.php:27
* @route '/money/cash-book'
*/
cashBookForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cashBook.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

cashBook.form = cashBookForm

/**
* @see \App\Http\Controllers\Money\DayController::day
* @see app/Http/Controllers/Money/DayController.php:22
* @route '/money/day'
*/
export const day = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: day.url(options),
    method: 'get',
})

day.definition = {
    methods: ["get","head"],
    url: '/money/day',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Money\DayController::day
* @see app/Http/Controllers/Money/DayController.php:22
* @route '/money/day'
*/
day.url = (options?: RouteQueryOptions) => {
    return day.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\DayController::day
* @see app/Http/Controllers/Money/DayController.php:22
* @route '/money/day'
*/
day.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: day.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\DayController::day
* @see app/Http/Controllers/Money/DayController.php:22
* @route '/money/day'
*/
day.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: day.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Money\DayController::day
* @see app/Http/Controllers/Money/DayController.php:22
* @route '/money/day'
*/
const dayForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: day.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\DayController::day
* @see app/Http/Controllers/Money/DayController.php:22
* @route '/money/day'
*/
dayForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: day.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\DayController::day
* @see app/Http/Controllers/Money/DayController.php:22
* @route '/money/day'
*/
dayForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: day.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

day.form = dayForm

const money = {
    cashBook: Object.assign(cashBook, cashBookC51ebc),
    expenses: Object.assign(expenses, expenses),
    recurring: Object.assign(recurring, recurring),
    day: Object.assign(day, dayB024b4),
}

export default money