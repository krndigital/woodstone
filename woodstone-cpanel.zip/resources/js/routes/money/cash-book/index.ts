import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Money\CashBookController::entries
* @see app/Http/Controllers/Money/CashBookController.php:68
* @route '/money/cash-book/entries'
*/
export const entries = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: entries.url(options),
    method: 'post',
})

entries.definition = {
    methods: ["post"],
    url: '/money/cash-book/entries',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Money\CashBookController::entries
* @see app/Http/Controllers/Money/CashBookController.php:68
* @route '/money/cash-book/entries'
*/
entries.url = (options?: RouteQueryOptions) => {
    return entries.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\CashBookController::entries
* @see app/Http/Controllers/Money/CashBookController.php:68
* @route '/money/cash-book/entries'
*/
entries.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: entries.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::entries
* @see app/Http/Controllers/Money/CashBookController.php:68
* @route '/money/cash-book/entries'
*/
const entriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: entries.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::entries
* @see app/Http/Controllers/Money/CashBookController.php:68
* @route '/money/cash-book/entries'
*/
entriesForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: entries.url(options),
    method: 'post',
})

entries.form = entriesForm

/**
* @see \App\Http\Controllers\Money\CashBookController::transfers
* @see app/Http/Controllers/Money/CashBookController.php:83
* @route '/money/cash-book/transfers'
*/
export const transfers = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: transfers.url(options),
    method: 'post',
})

transfers.definition = {
    methods: ["post"],
    url: '/money/cash-book/transfers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Money\CashBookController::transfers
* @see app/Http/Controllers/Money/CashBookController.php:83
* @route '/money/cash-book/transfers'
*/
transfers.url = (options?: RouteQueryOptions) => {
    return transfers.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\CashBookController::transfers
* @see app/Http/Controllers/Money/CashBookController.php:83
* @route '/money/cash-book/transfers'
*/
transfers.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: transfers.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::transfers
* @see app/Http/Controllers/Money/CashBookController.php:83
* @route '/money/cash-book/transfers'
*/
const transfersForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: transfers.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\CashBookController::transfers
* @see app/Http/Controllers/Money/CashBookController.php:83
* @route '/money/cash-book/transfers'
*/
transfersForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: transfers.url(options),
    method: 'post',
})

transfers.form = transfersForm

const cashBook = {
    entries: Object.assign(entries, entries),
    transfers: Object.assign(transfers, transfers),
}

export default cashBook