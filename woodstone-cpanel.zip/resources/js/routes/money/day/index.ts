import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Money\DayController::open
* @see app/Http/Controllers/Money/DayController.php:49
* @route '/money/day/open'
*/
export const open = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: open.url(options),
    method: 'post',
})

open.definition = {
    methods: ["post"],
    url: '/money/day/open',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Money\DayController::open
* @see app/Http/Controllers/Money/DayController.php:49
* @route '/money/day/open'
*/
open.url = (options?: RouteQueryOptions) => {
    return open.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\DayController::open
* @see app/Http/Controllers/Money/DayController.php:49
* @route '/money/day/open'
*/
open.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: open.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\DayController::open
* @see app/Http/Controllers/Money/DayController.php:49
* @route '/money/day/open'
*/
const openForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: open.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\DayController::open
* @see app/Http/Controllers/Money/DayController.php:49
* @route '/money/day/open'
*/
openForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: open.url(options),
    method: 'post',
})

open.form = openForm

/**
* @see \App\Http\Controllers\Money\DayController::close
* @see app/Http/Controllers/Money/DayController.php:57
* @route '/money/day/close'
*/
export const close = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(options),
    method: 'post',
})

close.definition = {
    methods: ["post"],
    url: '/money/day/close',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Money\DayController::close
* @see app/Http/Controllers/Money/DayController.php:57
* @route '/money/day/close'
*/
close.url = (options?: RouteQueryOptions) => {
    return close.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\DayController::close
* @see app/Http/Controllers/Money/DayController.php:57
* @route '/money/day/close'
*/
close.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\DayController::close
* @see app/Http/Controllers/Money/DayController.php:57
* @route '/money/day/close'
*/
const closeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: close.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\DayController::close
* @see app/Http/Controllers/Money/DayController.php:57
* @route '/money/day/close'
*/
closeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: close.url(options),
    method: 'post',
})

close.form = closeForm

const day = {
    open: Object.assign(open, open),
    close: Object.assign(close, close),
}

export default day