import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Money\ExpenseController::voidMethod
* @see app/Http/Controllers/Money/ExpenseController.php:100
* @route '/money/expenses/{expense}/void'
*/
export const voidMethod = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: voidMethod.url(args, options),
    method: 'patch',
})

voidMethod.definition = {
    methods: ["patch"],
    url: '/money/expenses/{expense}/void',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Money\ExpenseController::voidMethod
* @see app/Http/Controllers/Money/ExpenseController.php:100
* @route '/money/expenses/{expense}/void'
*/
voidMethod.url = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expense: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { expense: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            expense: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        expense: typeof args.expense === 'object'
        ? args.expense.id
        : args.expense,
    }

    return voidMethod.definition.url
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\ExpenseController::voidMethod
* @see app/Http/Controllers/Money/ExpenseController.php:100
* @route '/money/expenses/{expense}/void'
*/
voidMethod.patch = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: voidMethod.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::voidMethod
* @see app/Http/Controllers/Money/ExpenseController.php:100
* @route '/money/expenses/{expense}/void'
*/
const voidMethodForm = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: voidMethod.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::voidMethod
* @see app/Http/Controllers/Money/ExpenseController.php:100
* @route '/money/expenses/{expense}/void'
*/
voidMethodForm.patch = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: voidMethod.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

voidMethod.form = voidMethodForm

/**
* @see \App\Http\Controllers\Money\ExpenseController::index
* @see app/Http/Controllers/Money/ExpenseController.php:32
* @route '/money/expenses'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/money/expenses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Money\ExpenseController::index
* @see app/Http/Controllers/Money/ExpenseController.php:32
* @route '/money/expenses'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\ExpenseController::index
* @see app/Http/Controllers/Money/ExpenseController.php:32
* @route '/money/expenses'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::index
* @see app/Http/Controllers/Money/ExpenseController.php:32
* @route '/money/expenses'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::index
* @see app/Http/Controllers/Money/ExpenseController.php:32
* @route '/money/expenses'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::index
* @see app/Http/Controllers/Money/ExpenseController.php:32
* @route '/money/expenses'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::index
* @see app/Http/Controllers/Money/ExpenseController.php:32
* @route '/money/expenses'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Money\ExpenseController::store
* @see app/Http/Controllers/Money/ExpenseController.php:78
* @route '/money/expenses'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/money/expenses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Money\ExpenseController::store
* @see app/Http/Controllers/Money/ExpenseController.php:78
* @route '/money/expenses'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\ExpenseController::store
* @see app/Http/Controllers/Money/ExpenseController.php:78
* @route '/money/expenses'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::store
* @see app/Http/Controllers/Money/ExpenseController.php:78
* @route '/money/expenses'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::store
* @see app/Http/Controllers/Money/ExpenseController.php:78
* @route '/money/expenses'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Money\ExpenseController::receipt
* @see app/Http/Controllers/Money/ExpenseController.php:107
* @route '/money/expenses/{expense}/receipt'
*/
export const receipt = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipt.url(args, options),
    method: 'get',
})

receipt.definition = {
    methods: ["get","head"],
    url: '/money/expenses/{expense}/receipt',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Money\ExpenseController::receipt
* @see app/Http/Controllers/Money/ExpenseController.php:107
* @route '/money/expenses/{expense}/receipt'
*/
receipt.url = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expense: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { expense: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            expense: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        expense: typeof args.expense === 'object'
        ? args.expense.id
        : args.expense,
    }

    return receipt.definition.url
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Money\ExpenseController::receipt
* @see app/Http/Controllers/Money/ExpenseController.php:107
* @route '/money/expenses/{expense}/receipt'
*/
receipt.get = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: receipt.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::receipt
* @see app/Http/Controllers/Money/ExpenseController.php:107
* @route '/money/expenses/{expense}/receipt'
*/
receipt.head = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: receipt.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::receipt
* @see app/Http/Controllers/Money/ExpenseController.php:107
* @route '/money/expenses/{expense}/receipt'
*/
const receiptForm = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipt.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::receipt
* @see app/Http/Controllers/Money/ExpenseController.php:107
* @route '/money/expenses/{expense}/receipt'
*/
receiptForm.get = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipt.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Money\ExpenseController::receipt
* @see app/Http/Controllers/Money/ExpenseController.php:107
* @route '/money/expenses/{expense}/receipt'
*/
receiptForm.head = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: receipt.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

receipt.form = receiptForm

const expenses = {
    void: Object.assign(voidMethod, voidMethod),
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    receipt: Object.assign(receipt, receipt),
}

export default expenses