import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Accounting\AccountingController::store
* @see app/Http/Controllers/Accounting/AccountingController.php:43
* @route '/accounting/journals'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/accounting/journals',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Accounting\AccountingController::store
* @see app/Http/Controllers/Accounting/AccountingController.php:43
* @route '/accounting/journals'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Accounting\AccountingController::store
* @see app/Http/Controllers/Accounting/AccountingController.php:43
* @route '/accounting/journals'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Accounting\AccountingController::store
* @see app/Http/Controllers/Accounting/AccountingController.php:43
* @route '/accounting/journals'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Accounting\AccountingController::store
* @see app/Http/Controllers/Accounting/AccountingController.php:43
* @route '/accounting/journals'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const journals = {
    store: Object.assign(store, store),
}

export default journals