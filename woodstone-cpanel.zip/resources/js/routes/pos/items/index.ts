import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Pos\PosController::update
* @see app/Http/Controllers/Pos/PosController.php:123
* @route '/pos/order-items/{orderItem}'
*/
export const update = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/pos/order-items/{orderItem}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Pos\PosController::update
* @see app/Http/Controllers/Pos/PosController.php:123
* @route '/pos/order-items/{orderItem}'
*/
update.url = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { orderItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            orderItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        orderItem: typeof args.orderItem === 'object'
        ? args.orderItem.id
        : args.orderItem,
    }

    return update.definition.url
            .replace('{orderItem}', parsedArgs.orderItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::update
* @see app/Http/Controllers/Pos/PosController.php:123
* @route '/pos/order-items/{orderItem}'
*/
update.patch = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Pos\PosController::update
* @see app/Http/Controllers/Pos/PosController.php:123
* @route '/pos/order-items/{orderItem}'
*/
const updateForm = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::update
* @see app/Http/Controllers/Pos/PosController.php:123
* @route '/pos/order-items/{orderItem}'
*/
updateForm.patch = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Pos\PosController::destroy
* @see app/Http/Controllers/Pos/PosController.php:138
* @route '/pos/order-items/{orderItem}'
*/
export const destroy = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/pos/order-items/{orderItem}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Pos\PosController::destroy
* @see app/Http/Controllers/Pos/PosController.php:138
* @route '/pos/order-items/{orderItem}'
*/
destroy.url = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { orderItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            orderItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        orderItem: typeof args.orderItem === 'object'
        ? args.orderItem.id
        : args.orderItem,
    }

    return destroy.definition.url
            .replace('{orderItem}', parsedArgs.orderItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::destroy
* @see app/Http/Controllers/Pos/PosController.php:138
* @route '/pos/order-items/{orderItem}'
*/
destroy.delete = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Pos\PosController::destroy
* @see app/Http/Controllers/Pos/PosController.php:138
* @route '/pos/order-items/{orderItem}'
*/
const destroyForm = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::destroy
* @see app/Http/Controllers/Pos/PosController.php:138
* @route '/pos/order-items/{orderItem}'
*/
destroyForm.delete = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\Pos\PosController::voidMethod
* @see app/Http/Controllers/Pos/PosController.php:159
* @route '/pos/order-items/{orderItem}/void'
*/
export const voidMethod = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: voidMethod.url(args, options),
    method: 'post',
})

voidMethod.definition = {
    methods: ["post"],
    url: '/pos/order-items/{orderItem}/void',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::voidMethod
* @see app/Http/Controllers/Pos/PosController.php:159
* @route '/pos/order-items/{orderItem}/void'
*/
voidMethod.url = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { orderItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            orderItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        orderItem: typeof args.orderItem === 'object'
        ? args.orderItem.id
        : args.orderItem,
    }

    return voidMethod.definition.url
            .replace('{orderItem}', parsedArgs.orderItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::voidMethod
* @see app/Http/Controllers/Pos/PosController.php:159
* @route '/pos/order-items/{orderItem}/void'
*/
voidMethod.post = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: voidMethod.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::voidMethod
* @see app/Http/Controllers/Pos/PosController.php:159
* @route '/pos/order-items/{orderItem}/void'
*/
const voidMethodForm = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: voidMethod.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::voidMethod
* @see app/Http/Controllers/Pos/PosController.php:159
* @route '/pos/order-items/{orderItem}/void'
*/
voidMethodForm.post = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: voidMethod.url(args, options),
    method: 'post',
})

voidMethod.form = voidMethodForm

/**
* @see \App\Http\Controllers\Pos\PosController::served
* @see app/Http/Controllers/Pos/PosController.php:176
* @route '/pos/order-items/{orderItem}/served'
*/
export const served = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: served.url(args, options),
    method: 'patch',
})

served.definition = {
    methods: ["patch"],
    url: '/pos/order-items/{orderItem}/served',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Pos\PosController::served
* @see app/Http/Controllers/Pos/PosController.php:176
* @route '/pos/order-items/{orderItem}/served'
*/
served.url = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { orderItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { orderItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            orderItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        orderItem: typeof args.orderItem === 'object'
        ? args.orderItem.id
        : args.orderItem,
    }

    return served.definition.url
            .replace('{orderItem}', parsedArgs.orderItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::served
* @see app/Http/Controllers/Pos/PosController.php:176
* @route '/pos/order-items/{orderItem}/served'
*/
served.patch = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: served.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Pos\PosController::served
* @see app/Http/Controllers/Pos/PosController.php:176
* @route '/pos/order-items/{orderItem}/served'
*/
const servedForm = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: served.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::served
* @see app/Http/Controllers/Pos/PosController.php:176
* @route '/pos/order-items/{orderItem}/served'
*/
servedForm.patch = (args: { orderItem: number | { id: number } } | [orderItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: served.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

served.form = servedForm

const items = {
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
    void: Object.assign(voidMethod, voidMethod),
    served: Object.assign(served, served),
}

export default items