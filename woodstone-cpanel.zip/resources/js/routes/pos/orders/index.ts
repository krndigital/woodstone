import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import items from './items'
/**
* @see \App\Http\Controllers\Pos\PosController::store
* @see app/Http/Controllers/Pos/PosController.php:88
* @route '/pos/orders'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/pos/orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::store
* @see app/Http/Controllers/Pos/PosController.php:88
* @route '/pos/orders'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::store
* @see app/Http/Controllers/Pos/PosController.php:88
* @route '/pos/orders'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::store
* @see app/Http/Controllers/Pos/PosController.php:88
* @route '/pos/orders'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::store
* @see app/Http/Controllers/Pos/PosController.php:88
* @route '/pos/orders'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
export const show = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/pos/orders/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
show.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return show.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
show.get = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
show.head = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
const showForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
showForm.get = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::show
* @see app/Http/Controllers/Pos/PosController.php:64
* @route '/pos/orders/{order}'
*/
showForm.head = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Pos\PosController::kot
* @see app/Http/Controllers/Pos/PosController.php:149
* @route '/pos/orders/{order}/kot'
*/
export const kot = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: kot.url(args, options),
    method: 'post',
})

kot.definition = {
    methods: ["post"],
    url: '/pos/orders/{order}/kot',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::kot
* @see app/Http/Controllers/Pos/PosController.php:149
* @route '/pos/orders/{order}/kot'
*/
kot.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return kot.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::kot
* @see app/Http/Controllers/Pos/PosController.php:149
* @route '/pos/orders/{order}/kot'
*/
kot.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: kot.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::kot
* @see app/Http/Controllers/Pos/PosController.php:149
* @route '/pos/orders/{order}/kot'
*/
const kotForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: kot.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::kot
* @see app/Http/Controllers/Pos/PosController.php:149
* @route '/pos/orders/{order}/kot'
*/
kotForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: kot.url(args, options),
    method: 'post',
})

kot.form = kotForm

/**
* @see \App\Http\Controllers\Pos\PosController::move
* @see app/Http/Controllers/Pos/PosController.php:190
* @route '/pos/orders/{order}/move'
*/
export const move = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: move.url(args, options),
    method: 'post',
})

move.definition = {
    methods: ["post"],
    url: '/pos/orders/{order}/move',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::move
* @see app/Http/Controllers/Pos/PosController.php:190
* @route '/pos/orders/{order}/move'
*/
move.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return move.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::move
* @see app/Http/Controllers/Pos/PosController.php:190
* @route '/pos/orders/{order}/move'
*/
move.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: move.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::move
* @see app/Http/Controllers/Pos/PosController.php:190
* @route '/pos/orders/{order}/move'
*/
const moveForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: move.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::move
* @see app/Http/Controllers/Pos/PosController.php:190
* @route '/pos/orders/{order}/move'
*/
moveForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: move.url(args, options),
    method: 'post',
})

move.form = moveForm

/**
* @see \App\Http\Controllers\Pos\PosController::merge
* @see app/Http/Controllers/Pos/PosController.php:198
* @route '/pos/orders/{order}/merge'
*/
export const merge = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: merge.url(args, options),
    method: 'post',
})

merge.definition = {
    methods: ["post"],
    url: '/pos/orders/{order}/merge',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::merge
* @see app/Http/Controllers/Pos/PosController.php:198
* @route '/pos/orders/{order}/merge'
*/
merge.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return merge.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::merge
* @see app/Http/Controllers/Pos/PosController.php:198
* @route '/pos/orders/{order}/merge'
*/
merge.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: merge.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::merge
* @see app/Http/Controllers/Pos/PosController.php:198
* @route '/pos/orders/{order}/merge'
*/
const mergeForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: merge.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::merge
* @see app/Http/Controllers/Pos/PosController.php:198
* @route '/pos/orders/{order}/merge'
*/
mergeForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: merge.url(args, options),
    method: 'post',
})

merge.form = mergeForm

/**
* @see \App\Http\Controllers\Pos\PosController::cancel
* @see app/Http/Controllers/Pos/PosController.php:206
* @route '/pos/orders/{order}/cancel'
*/
export const cancel = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/pos/orders/{order}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Pos\PosController::cancel
* @see app/Http/Controllers/Pos/PosController.php:206
* @route '/pos/orders/{order}/cancel'
*/
cancel.url = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { order: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            order: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        order: typeof args.order === 'object'
        ? args.order.id
        : args.order,
    }

    return cancel.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::cancel
* @see app/Http/Controllers/Pos/PosController.php:206
* @route '/pos/orders/{order}/cancel'
*/
cancel.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::cancel
* @see app/Http/Controllers/Pos/PosController.php:206
* @route '/pos/orders/{order}/cancel'
*/
const cancelForm = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Pos\PosController::cancel
* @see app/Http/Controllers/Pos/PosController.php:206
* @route '/pos/orders/{order}/cancel'
*/
cancelForm.post = (args: { order: number | { id: number } } | [order: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(args, options),
    method: 'post',
})

cancel.form = cancelForm

const orders = {
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    items: Object.assign(items, items),
    kot: Object.assign(kot, kot),
    move: Object.assign(move, move),
    merge: Object.assign(merge, merge),
    cancel: Object.assign(cancel, cancel),
}

export default orders