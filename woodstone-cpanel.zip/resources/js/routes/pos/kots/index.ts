import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Pos\PosController::print
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
export const print = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

print.definition = {
    methods: ["get","head"],
    url: '/pos/kots/{kot}/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Pos\PosController::print
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
print.url = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kot: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { kot: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            kot: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kot: typeof args.kot === 'object'
        ? args.kot.id
        : args.kot,
    }

    return print.definition.url
            .replace('{kot}', parsedArgs.kot.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Pos\PosController::print
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
print.get = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::print
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
print.head = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: print.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Pos\PosController::print
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
const printForm = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::print
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
printForm.get = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Pos\PosController::print
* @see app/Http/Controllers/Pos/PosController.php:217
* @route '/pos/kots/{kot}/print'
*/
printForm.head = (args: { kot: number | { id: number } } | [kot: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

print.form = printForm

const kots = {
    print: Object.assign(print, print),
}

export default kots