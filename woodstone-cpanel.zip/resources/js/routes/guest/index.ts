import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import calls from './calls'
/**
* @see \App\Http\Controllers\Guest\GuestController::table
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
export const table = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: table.url(args, options),
    method: 'get',
})

table.definition = {
    methods: ["get","head"],
    url: '/t/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Guest\GuestController::table
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
table.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return table.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Guest\GuestController::table
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
table.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: table.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::table
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
table.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: table.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::table
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
const tableForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: table.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::table
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
tableForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: table.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::table
* @see app/Http/Controllers/Guest/GuestController.php:30
* @route '/t/{token}'
*/
tableForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: table.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

table.form = tableForm

const guest = {
    table: Object.assign(table, table),
    calls: Object.assign(calls, calls),
}

export default guest