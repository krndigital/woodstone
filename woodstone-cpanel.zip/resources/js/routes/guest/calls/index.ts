import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
export const status = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(args, options),
    method: 'get',
})

status.definition = {
    methods: ["get","head"],
    url: '/t/{token}/calls/{publicId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
status.url = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            token: args[0],
            publicId: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
        publicId: args.publicId,
    }

    return status.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace('{publicId}', parsedArgs.publicId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
status.get = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
status.head = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
const statusForm = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
statusForm.get = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::status
* @see app/Http/Controllers/Guest/GuestController.php:82
* @route '/t/{token}/calls/{publicId}'
*/
statusForm.head = (args: { token: string | number, publicId: string | number } | [token: string | number, publicId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

status.form = statusForm

/**
* @see \App\Http\Controllers\Guest\GuestController::store
* @see app/Http/Controllers/Guest/GuestController.php:51
* @route '/t/{token}/calls'
*/
export const store = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/t/{token}/calls',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Guest\GuestController::store
* @see app/Http/Controllers/Guest/GuestController.php:51
* @route '/t/{token}/calls'
*/
store.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return store.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Guest\GuestController::store
* @see app/Http/Controllers/Guest/GuestController.php:51
* @route '/t/{token}/calls'
*/
store.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::store
* @see app/Http/Controllers/Guest/GuestController.php:51
* @route '/t/{token}/calls'
*/
const storeForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Guest\GuestController::store
* @see app/Http/Controllers/Guest/GuestController.php:51
* @route '/t/{token}/calls'
*/
storeForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

const calls = {
    status: Object.assign(status, status),
    store: Object.assign(store, store),
}

export default calls