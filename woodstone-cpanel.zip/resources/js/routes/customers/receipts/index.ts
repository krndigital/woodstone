import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Dues\CustomerController::print
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
export const print = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

print.definition = {
    methods: ["get","head"],
    url: '/customer-receipts/{entry}/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Dues\CustomerController::print
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
print.url = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { entry: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { entry: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            entry: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        entry: typeof args.entry === 'object'
        ? args.entry.id
        : args.entry,
    }

    return print.definition.url
            .replace('{entry}', parsedArgs.entry.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Dues\CustomerController::print
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
print.get = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::print
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
print.head = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: print.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::print
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
const printForm = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::print
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
printForm.get = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::print
* @see app/Http/Controllers/Dues/CustomerController.php:223
* @route '/customer-receipts/{entry}/print'
*/
printForm.head = (args: { entry: number | { id: number } } | [entry: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

print.form = printForm

const receipts = {
    print: Object.assign(print, print),
}

export default receipts