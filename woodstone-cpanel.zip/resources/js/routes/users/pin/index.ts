import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\UserController::clear
* @see app/Http/Controllers/UserController.php:146
* @route '/users/{user}/pin'
*/
export const clear = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clear.url(args, options),
    method: 'delete',
})

clear.definition = {
    methods: ["delete"],
    url: '/users/{user}/pin',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\UserController::clear
* @see app/Http/Controllers/UserController.php:146
* @route '/users/{user}/pin'
*/
clear.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return clear.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::clear
* @see app/Http/Controllers/UserController.php:146
* @route '/users/{user}/pin'
*/
clear.delete = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clear.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\UserController::clear
* @see app/Http/Controllers/UserController.php:146
* @route '/users/{user}/pin'
*/
const clearForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: clear.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::clear
* @see app/Http/Controllers/UserController.php:146
* @route '/users/{user}/pin'
*/
clearForm.delete = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: clear.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

clear.form = clearForm

/**
* @see \App\Http\Controllers\UserController::unlock
* @see app/Http/Controllers/UserController.php:158
* @route '/users/{user}/pin/unlock'
*/
export const unlock = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: unlock.url(args, options),
    method: 'patch',
})

unlock.definition = {
    methods: ["patch"],
    url: '/users/{user}/pin/unlock',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\UserController::unlock
* @see app/Http/Controllers/UserController.php:158
* @route '/users/{user}/pin/unlock'
*/
unlock.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return unlock.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::unlock
* @see app/Http/Controllers/UserController.php:158
* @route '/users/{user}/pin/unlock'
*/
unlock.patch = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: unlock.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\UserController::unlock
* @see app/Http/Controllers/UserController.php:158
* @route '/users/{user}/pin/unlock'
*/
const unlockForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: unlock.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\UserController::unlock
* @see app/Http/Controllers/UserController.php:158
* @route '/users/{user}/pin/unlock'
*/
unlockForm.patch = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: unlock.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

unlock.form = unlockForm

const pin = {
    clear: Object.assign(clear, clear),
    unlock: Object.assign(unlock, unlock),
}

export default pin