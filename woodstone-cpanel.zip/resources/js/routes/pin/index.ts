import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\PinLoginController::create
* @see app/Http/Controllers/Auth/PinLoginController.php:31
* @route '/pin'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/pin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\PinLoginController::create
* @see app/Http/Controllers/Auth/PinLoginController.php:31
* @route '/pin'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\PinLoginController::create
* @see app/Http/Controllers/Auth/PinLoginController.php:31
* @route '/pin'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\PinLoginController::create
* @see app/Http/Controllers/Auth/PinLoginController.php:31
* @route '/pin'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Auth\PinLoginController::create
* @see app/Http/Controllers/Auth/PinLoginController.php:31
* @route '/pin'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\PinLoginController::create
* @see app/Http/Controllers/Auth/PinLoginController.php:31
* @route '/pin'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Auth\PinLoginController::create
* @see app/Http/Controllers/Auth/PinLoginController.php:31
* @route '/pin'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Auth\PinLoginController::store
* @see app/Http/Controllers/Auth/PinLoginController.php:57
* @route '/pin'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/pin',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\PinLoginController::store
* @see app/Http/Controllers/Auth/PinLoginController.php:57
* @route '/pin'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\PinLoginController::store
* @see app/Http/Controllers/Auth/PinLoginController.php:57
* @route '/pin'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Auth\PinLoginController::store
* @see app/Http/Controllers/Auth/PinLoginController.php:57
* @route '/pin'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Auth\PinLoginController::store
* @see app/Http/Controllers/Auth/PinLoginController.php:57
* @route '/pin'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const pin = {
    create: Object.assign(create, create),
    store: Object.assign(store, store),
}

export default pin