import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Staff\PayrollController::update
* @see app/Http/Controllers/Staff/PayrollController.php:49
* @route '/staff/payslips/{payslip}'
*/
export const update = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/staff/payslips/{payslip}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Staff\PayrollController::update
* @see app/Http/Controllers/Staff/PayrollController.php:49
* @route '/staff/payslips/{payslip}'
*/
update.url = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payslip: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { payslip: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            payslip: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        payslip: typeof args.payslip === 'object'
        ? args.payslip.id
        : args.payslip,
    }

    return update.definition.url
            .replace('{payslip}', parsedArgs.payslip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\PayrollController::update
* @see app/Http/Controllers/Staff/PayrollController.php:49
* @route '/staff/payslips/{payslip}'
*/
update.patch = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::update
* @see app/Http/Controllers/Staff/PayrollController.php:49
* @route '/staff/payslips/{payslip}'
*/
const updateForm = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::update
* @see app/Http/Controllers/Staff/PayrollController.php:49
* @route '/staff/payslips/{payslip}'
*/
updateForm.patch = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Staff\PayrollController::pay
* @see app/Http/Controllers/Staff/PayrollController.php:56
* @route '/staff/payslips/{payslip}/pay'
*/
export const pay = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

pay.definition = {
    methods: ["post"],
    url: '/staff/payslips/{payslip}/pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Staff\PayrollController::pay
* @see app/Http/Controllers/Staff/PayrollController.php:56
* @route '/staff/payslips/{payslip}/pay'
*/
pay.url = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payslip: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { payslip: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            payslip: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        payslip: typeof args.payslip === 'object'
        ? args.payslip.id
        : args.payslip,
    }

    return pay.definition.url
            .replace('{payslip}', parsedArgs.payslip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\PayrollController::pay
* @see app/Http/Controllers/Staff/PayrollController.php:56
* @route '/staff/payslips/{payslip}/pay'
*/
pay.post = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::pay
* @see app/Http/Controllers/Staff/PayrollController.php:56
* @route '/staff/payslips/{payslip}/pay'
*/
const payForm = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pay.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::pay
* @see app/Http/Controllers/Staff/PayrollController.php:56
* @route '/staff/payslips/{payslip}/pay'
*/
payForm.post = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pay.url(args, options),
    method: 'post',
})

pay.form = payForm

/**
* @see \App\Http\Controllers\Staff\PayrollController::print
* @see app/Http/Controllers/Staff/PayrollController.php:64
* @route '/staff/payslips/{payslip}/print'
*/
export const print = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

print.definition = {
    methods: ["get","head"],
    url: '/staff/payslips/{payslip}/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Staff\PayrollController::print
* @see app/Http/Controllers/Staff/PayrollController.php:64
* @route '/staff/payslips/{payslip}/print'
*/
print.url = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payslip: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { payslip: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            payslip: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        payslip: typeof args.payslip === 'object'
        ? args.payslip.id
        : args.payslip,
    }

    return print.definition.url
            .replace('{payslip}', parsedArgs.payslip.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\PayrollController::print
* @see app/Http/Controllers/Staff/PayrollController.php:64
* @route '/staff/payslips/{payslip}/print'
*/
print.get = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::print
* @see app/Http/Controllers/Staff/PayrollController.php:64
* @route '/staff/payslips/{payslip}/print'
*/
print.head = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: print.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::print
* @see app/Http/Controllers/Staff/PayrollController.php:64
* @route '/staff/payslips/{payslip}/print'
*/
const printForm = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::print
* @see app/Http/Controllers/Staff/PayrollController.php:64
* @route '/staff/payslips/{payslip}/print'
*/
printForm.get = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::print
* @see app/Http/Controllers/Staff/PayrollController.php:64
* @route '/staff/payslips/{payslip}/print'
*/
printForm.head = (args: { payslip: number | { id: number } } | [payslip: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

print.form = printForm

const payslips = {
    update: Object.assign(update, update),
    pay: Object.assign(pay, pay),
    print: Object.assign(print, print),
}

export default payslips