import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Staff\StaffController::mark
* @see app/Http/Controllers/Staff/StaffController.php:109
* @route '/staff/{staff}/attendance'
*/
export const mark = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: mark.url(args, options),
    method: 'put',
})

mark.definition = {
    methods: ["put"],
    url: '/staff/{staff}/attendance',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::mark
* @see app/Http/Controllers/Staff/StaffController.php:109
* @route '/staff/{staff}/attendance'
*/
mark.url = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { staff: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { staff: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            staff: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        staff: typeof args.staff === 'object'
        ? args.staff.id
        : args.staff,
    }

    return mark.definition.url
            .replace('{staff}', parsedArgs.staff.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::mark
* @see app/Http/Controllers/Staff/StaffController.php:109
* @route '/staff/{staff}/attendance'
*/
mark.put = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: mark.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::mark
* @see app/Http/Controllers/Staff/StaffController.php:109
* @route '/staff/{staff}/attendance'
*/
const markForm = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: mark.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::mark
* @see app/Http/Controllers/Staff/StaffController.php:109
* @route '/staff/{staff}/attendance'
*/
markForm.put = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: mark.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

mark.form = markForm

const attendance = {
    mark: Object.assign(mark, mark),
}

export default attendance