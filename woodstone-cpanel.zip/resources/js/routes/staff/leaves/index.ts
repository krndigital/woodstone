import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:89
* @route '/staff/leaves'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/staff/leaves',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:89
* @route '/staff/leaves'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:89
* @route '/staff/leaves'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:89
* @route '/staff/leaves'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:89
* @route '/staff/leaves'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:101
* @route '/staff/leaves/{leave}'
*/
export const update = (args: { leave: number | { id: number } } | [leave: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/staff/leaves/{leave}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:101
* @route '/staff/leaves/{leave}'
*/
update.url = (args: { leave: number | { id: number } } | [leave: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leave: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { leave: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            leave: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        leave: typeof args.leave === 'object'
        ? args.leave.id
        : args.leave,
    }

    return update.definition.url
            .replace('{leave}', parsedArgs.leave.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:101
* @route '/staff/leaves/{leave}'
*/
update.patch = (args: { leave: number | { id: number } } | [leave: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:101
* @route '/staff/leaves/{leave}'
*/
const updateForm = (args: { leave: number | { id: number } } | [leave: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:101
* @route '/staff/leaves/{leave}'
*/
updateForm.patch = (args: { leave: number | { id: number } } | [leave: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const leaves = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
}

export default leaves