import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import advances from './advances'
import attendance from './attendance'
import leaves from './leaves'
import payrollCe309f from './payroll'
import payslips from './payslips'
/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/staff',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::index
* @see app/Http/Controllers/Staff/StaffController.php:28
* @route '/staff'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:59
* @route '/staff'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/staff',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:59
* @route '/staff'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:59
* @route '/staff'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:59
* @route '/staff'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:59
* @route '/staff'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:70
* @route '/staff/{staff}'
*/
export const update = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/staff/{staff}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:70
* @route '/staff/{staff}'
*/
update.url = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { staff: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { staff: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            staff: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        staff: typeof args.staff === 'object'
        ? args.staff.id
        : args.staff,
    }

    return update.definition.url
            .replace('{staff}', parsedArgs.staff.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:70
* @route '/staff/{staff}'
*/
update.put = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:70
* @route '/staff/{staff}'
*/
const updateForm = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::update
* @see app/Http/Controllers/Staff/StaffController.php:70
* @route '/staff/{staff}'
*/
updateForm.put = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Staff\PayrollController::payroll
* @see app/Http/Controllers/Staff/PayrollController.php:24
* @route '/staff/payroll'
*/
export const payroll = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payroll.url(options),
    method: 'get',
})

payroll.definition = {
    methods: ["get","head"],
    url: '/staff/payroll',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Staff\PayrollController::payroll
* @see app/Http/Controllers/Staff/PayrollController.php:24
* @route '/staff/payroll'
*/
payroll.url = (options?: RouteQueryOptions) => {
    return payroll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\PayrollController::payroll
* @see app/Http/Controllers/Staff/PayrollController.php:24
* @route '/staff/payroll'
*/
payroll.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payroll.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::payroll
* @see app/Http/Controllers/Staff/PayrollController.php:24
* @route '/staff/payroll'
*/
payroll.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: payroll.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::payroll
* @see app/Http/Controllers/Staff/PayrollController.php:24
* @route '/staff/payroll'
*/
const payrollForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payroll.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::payroll
* @see app/Http/Controllers/Staff/PayrollController.php:24
* @route '/staff/payroll'
*/
payrollForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payroll.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::payroll
* @see app/Http/Controllers/Staff/PayrollController.php:24
* @route '/staff/payroll'
*/
payrollForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payroll.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

payroll.form = payrollForm

const staff = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    advances: Object.assign(advances, advances),
    attendance: Object.assign(attendance, attendance),
    leaves: Object.assign(leaves, leaves),
    payroll: Object.assign(payroll, payrollCe309f),
    payslips: Object.assign(payslips, payslips),
}

export default staff