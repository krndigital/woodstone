import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:81
* @route '/staff/{staff}/advances'
*/
export const store = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/staff/{staff}/advances',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:81
* @route '/staff/{staff}/advances'
*/
store.url = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { staff: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { staff: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            staff: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        staff: typeof args.staff === 'object'
        ? args.staff.id
        : args.staff,
    }

    return store.definition.url
            .replace('{staff}', parsedArgs.staff.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:81
* @route '/staff/{staff}/advances'
*/
store.post = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:81
* @route '/staff/{staff}/advances'
*/
const storeForm = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\StaffController::store
* @see app/Http/Controllers/Staff/StaffController.php:81
* @route '/staff/{staff}/advances'
*/
storeForm.post = (args: { staff: number | { id: number } } | [staff: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

const advances = {
    store: Object.assign(store, store),
}

export default advances