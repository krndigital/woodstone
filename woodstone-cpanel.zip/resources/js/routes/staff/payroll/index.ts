import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Staff\PayrollController::generate
* @see app/Http/Controllers/Staff/PayrollController.php:41
* @route '/staff/payroll/generate'
*/
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/staff/payroll/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Staff\PayrollController::generate
* @see app/Http/Controllers/Staff/PayrollController.php:41
* @route '/staff/payroll/generate'
*/
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Staff\PayrollController::generate
* @see app/Http/Controllers/Staff/PayrollController.php:41
* @route '/staff/payroll/generate'
*/
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::generate
* @see app/Http/Controllers/Staff/PayrollController.php:41
* @route '/staff/payroll/generate'
*/
const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: generate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Staff\PayrollController::generate
* @see app/Http/Controllers/Staff/PayrollController.php:41
* @route '/staff/payroll/generate'
*/
generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: generate.url(options),
    method: 'post',
})

generate.form = generateForm

const payroll = {
    generate: Object.assign(generate, generate),
}

export default payroll