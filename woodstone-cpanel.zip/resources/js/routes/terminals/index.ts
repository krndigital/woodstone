import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\TerminalController::index
* @see app/Http/Controllers/TerminalController.php:21
* @route '/terminals'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/terminals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TerminalController::index
* @see app/Http/Controllers/TerminalController.php:21
* @route '/terminals'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TerminalController::index
* @see app/Http/Controllers/TerminalController.php:21
* @route '/terminals'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TerminalController::index
* @see app/Http/Controllers/TerminalController.php:21
* @route '/terminals'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\TerminalController::index
* @see app/Http/Controllers/TerminalController.php:21
* @route '/terminals'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TerminalController::index
* @see app/Http/Controllers/TerminalController.php:21
* @route '/terminals'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TerminalController::index
* @see app/Http/Controllers/TerminalController.php:21
* @route '/terminals'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\TerminalController::store
* @see app/Http/Controllers/TerminalController.php:46
* @route '/terminals'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/terminals',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TerminalController::store
* @see app/Http/Controllers/TerminalController.php:46
* @route '/terminals'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TerminalController::store
* @see app/Http/Controllers/TerminalController.php:46
* @route '/terminals'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TerminalController::store
* @see app/Http/Controllers/TerminalController.php:46
* @route '/terminals'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TerminalController::store
* @see app/Http/Controllers/TerminalController.php:46
* @route '/terminals'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\TerminalController::destroy
* @see app/Http/Controllers/TerminalController.php:66
* @route '/terminals/{terminal}'
*/
export const destroy = (args: { terminal: number | { id: number } } | [terminal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/terminals/{terminal}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TerminalController::destroy
* @see app/Http/Controllers/TerminalController.php:66
* @route '/terminals/{terminal}'
*/
destroy.url = (args: { terminal: number | { id: number } } | [terminal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { terminal: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { terminal: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            terminal: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        terminal: typeof args.terminal === 'object'
        ? args.terminal.id
        : args.terminal,
    }

    return destroy.definition.url
            .replace('{terminal}', parsedArgs.terminal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TerminalController::destroy
* @see app/Http/Controllers/TerminalController.php:66
* @route '/terminals/{terminal}'
*/
destroy.delete = (args: { terminal: number | { id: number } } | [terminal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\TerminalController::destroy
* @see app/Http/Controllers/TerminalController.php:66
* @route '/terminals/{terminal}'
*/
const destroyForm = (args: { terminal: number | { id: number } } | [terminal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TerminalController::destroy
* @see app/Http/Controllers/TerminalController.php:66
* @route '/terminals/{terminal}'
*/
destroyForm.delete = (args: { terminal: number | { id: number } } | [terminal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const terminals = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    destroy: Object.assign(destroy, destroy),
}

export default terminals