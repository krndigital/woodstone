import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Floor\FloorController::store
* @see app/Http/Controllers/Floor/FloorController.php:67
* @route '/floor/zones'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/floor/zones',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::store
* @see app/Http/Controllers/Floor/FloorController.php:67
* @route '/floor/zones'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::store
* @see app/Http/Controllers/Floor/FloorController.php:67
* @route '/floor/zones'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::store
* @see app/Http/Controllers/Floor/FloorController.php:67
* @route '/floor/zones'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::store
* @see app/Http/Controllers/Floor/FloorController.php:67
* @route '/floor/zones'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Floor\FloorController::update
* @see app/Http/Controllers/Floor/FloorController.php:79
* @route '/floor/zones/{zone}'
*/
export const update = (args: { zone: number | { id: number } } | [zone: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/floor/zones/{zone}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::update
* @see app/Http/Controllers/Floor/FloorController.php:79
* @route '/floor/zones/{zone}'
*/
update.url = (args: { zone: number | { id: number } } | [zone: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { zone: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { zone: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            zone: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        zone: typeof args.zone === 'object'
        ? args.zone.id
        : args.zone,
    }

    return update.definition.url
            .replace('{zone}', parsedArgs.zone.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::update
* @see app/Http/Controllers/Floor/FloorController.php:79
* @route '/floor/zones/{zone}'
*/
update.put = (args: { zone: number | { id: number } } | [zone: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::update
* @see app/Http/Controllers/Floor/FloorController.php:79
* @route '/floor/zones/{zone}'
*/
const updateForm = (args: { zone: number | { id: number } } | [zone: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::update
* @see app/Http/Controllers/Floor/FloorController.php:79
* @route '/floor/zones/{zone}'
*/
updateForm.put = (args: { zone: number | { id: number } } | [zone: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const zones = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
}

export default zones