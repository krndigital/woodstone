import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Floor\FloorController::status
* @see app/Http/Controllers/Floor/FloorController.php:48
* @route '/floor/tables/{table}/status'
*/
export const status = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/floor/tables/{table}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::status
* @see app/Http/Controllers/Floor/FloorController.php:48
* @route '/floor/tables/{table}/status'
*/
status.url = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { table: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { table: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            table: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        table: typeof args.table === 'object'
        ? args.table.id
        : args.table,
    }

    return status.definition.url
            .replace('{table}', parsedArgs.table.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::status
* @see app/Http/Controllers/Floor/FloorController.php:48
* @route '/floor/tables/{table}/status'
*/
status.patch = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::status
* @see app/Http/Controllers/Floor/FloorController.php:48
* @route '/floor/tables/{table}/status'
*/
const statusForm = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::status
* @see app/Http/Controllers/Floor/FloorController.php:48
* @route '/floor/tables/{table}/status'
*/
statusForm.patch = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

status.form = statusForm

/**
* @see \App\Http\Controllers\Floor\FloorController::store
* @see app/Http/Controllers/Floor/FloorController.php:92
* @route '/floor/tables'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/floor/tables',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::store
* @see app/Http/Controllers/Floor/FloorController.php:92
* @route '/floor/tables'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::store
* @see app/Http/Controllers/Floor/FloorController.php:92
* @route '/floor/tables'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::store
* @see app/Http/Controllers/Floor/FloorController.php:92
* @route '/floor/tables'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::store
* @see app/Http/Controllers/Floor/FloorController.php:92
* @route '/floor/tables'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Floor\FloorController::update
* @see app/Http/Controllers/Floor/FloorController.php:124
* @route '/floor/tables/{table}'
*/
export const update = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/floor/tables/{table}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::update
* @see app/Http/Controllers/Floor/FloorController.php:124
* @route '/floor/tables/{table}'
*/
update.url = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { table: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { table: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            table: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        table: typeof args.table === 'object'
        ? args.table.id
        : args.table,
    }

    return update.definition.url
            .replace('{table}', parsedArgs.table.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::update
* @see app/Http/Controllers/Floor/FloorController.php:124
* @route '/floor/tables/{table}'
*/
update.put = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::update
* @see app/Http/Controllers/Floor/FloorController.php:124
* @route '/floor/tables/{table}'
*/
const updateForm = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::update
* @see app/Http/Controllers/Floor/FloorController.php:124
* @route '/floor/tables/{table}'
*/
updateForm.put = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Floor\FloorController::qr
* @see app/Http/Controllers/Floor/FloorController.php:102
* @route '/floor/tables/{table}/qr'
*/
export const qr = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: qr.url(args, options),
    method: 'post',
})

qr.definition = {
    methods: ["post"],
    url: '/floor/tables/{table}/qr',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::qr
* @see app/Http/Controllers/Floor/FloorController.php:102
* @route '/floor/tables/{table}/qr'
*/
qr.url = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { table: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { table: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            table: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        table: typeof args.table === 'object'
        ? args.table.id
        : args.table,
    }

    return qr.definition.url
            .replace('{table}', parsedArgs.table.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::qr
* @see app/Http/Controllers/Floor/FloorController.php:102
* @route '/floor/tables/{table}/qr'
*/
qr.post = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: qr.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::qr
* @see app/Http/Controllers/Floor/FloorController.php:102
* @route '/floor/tables/{table}/qr'
*/
const qrForm = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: qr.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::qr
* @see app/Http/Controllers/Floor/FloorController.php:102
* @route '/floor/tables/{table}/qr'
*/
qrForm.post = (args: { table: number | { id: number } } | [table: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: qr.url(args, options),
    method: 'post',
})

qr.form = qrForm

const tables = {
    status: Object.assign(status, status),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    qr: Object.assign(qr, qr),
}

export default tables