import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import tables from './tables'
import zones from './zones'
import reservations from './reservations'
/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/floor',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::index
* @see app/Http/Controllers/Floor/FloorController.php:33
* @route '/floor'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
export const qrCards = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qrCards.url(options),
    method: 'get',
})

qrCards.definition = {
    methods: ["get","head"],
    url: '/floor/qr-cards',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
qrCards.url = (options?: RouteQueryOptions) => {
    return qrCards.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
qrCards.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qrCards.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
qrCards.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: qrCards.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
const qrCardsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qrCards.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
qrCardsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qrCards.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Floor\FloorController::qrCards
* @see app/Http/Controllers/Floor/FloorController.php:115
* @route '/floor/qr-cards'
*/
qrCardsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qrCards.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

qrCards.form = qrCardsForm

const floor = {
    index: Object.assign(index, index),
    tables: Object.assign(tables, tables),
    zones: Object.assign(zones, zones),
    qrCards: Object.assign(qrCards, qrCards),
    reservations: Object.assign(reservations, reservations),
}

export default floor