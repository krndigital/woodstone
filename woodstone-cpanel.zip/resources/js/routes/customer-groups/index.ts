import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Dues\CustomerController::store
* @see app/Http/Controllers/Dues/CustomerController.php:270
* @route '/customer-groups'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/customer-groups',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Dues\CustomerController::store
* @see app/Http/Controllers/Dues/CustomerController.php:270
* @route '/customer-groups'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Dues\CustomerController::store
* @see app/Http/Controllers/Dues/CustomerController.php:270
* @route '/customer-groups'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::store
* @see app/Http/Controllers/Dues/CustomerController.php:270
* @route '/customer-groups'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Dues\CustomerController::store
* @see app/Http/Controllers/Dues/CustomerController.php:270
* @route '/customer-groups'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const customerGroups = {
    store: Object.assign(store, store),
}

export default customerGroups