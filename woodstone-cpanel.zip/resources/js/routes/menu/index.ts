import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import items from './items'
import categories from './categories'
import stations from './stations'
/**
* @see \App\Http\Controllers\Menu\MenuController::index
* @see app/Http/Controllers/Menu/MenuController.php:25
* @route '/menu'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/menu',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Menu\MenuController::index
* @see app/Http/Controllers/Menu/MenuController.php:25
* @route '/menu'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Menu\MenuController::index
* @see app/Http/Controllers/Menu/MenuController.php:25
* @route '/menu'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Menu\MenuController::index
* @see app/Http/Controllers/Menu/MenuController.php:25
* @route '/menu'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Menu\MenuController::index
* @see app/Http/Controllers/Menu/MenuController.php:25
* @route '/menu'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Menu\MenuController::index
* @see app/Http/Controllers/Menu/MenuController.php:25
* @route '/menu'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Menu\MenuController::index
* @see app/Http/Controllers/Menu/MenuController.php:25
* @route '/menu'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Menu\MenuItemController::loadWoodstone
* @see app/Http/Controllers/Menu/MenuItemController.php:42
* @route '/menu/load-woodstone'
*/
export const loadWoodstone = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: loadWoodstone.url(options),
    method: 'post',
})

loadWoodstone.definition = {
    methods: ["post"],
    url: '/menu/load-woodstone',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Menu\MenuItemController::loadWoodstone
* @see app/Http/Controllers/Menu/MenuItemController.php:42
* @route '/menu/load-woodstone'
*/
loadWoodstone.url = (options?: RouteQueryOptions) => {
    return loadWoodstone.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Menu\MenuItemController::loadWoodstone
* @see app/Http/Controllers/Menu/MenuItemController.php:42
* @route '/menu/load-woodstone'
*/
loadWoodstone.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: loadWoodstone.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::loadWoodstone
* @see app/Http/Controllers/Menu/MenuItemController.php:42
* @route '/menu/load-woodstone'
*/
const loadWoodstoneForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: loadWoodstone.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\MenuItemController::loadWoodstone
* @see app/Http/Controllers/Menu/MenuItemController.php:42
* @route '/menu/load-woodstone'
*/
loadWoodstoneForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: loadWoodstone.url(options),
    method: 'post',
})

loadWoodstone.form = loadWoodstoneForm

const menu = {
    index: Object.assign(index, index),
    items: Object.assign(items, items),
    loadWoodstone: Object.assign(loadWoodstone, loadWoodstone),
    categories: Object.assign(categories, categories),
    stations: Object.assign(stations, stations),
}

export default menu