import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Menu\StationController::store
* @see app/Http/Controllers/Menu/StationController.php:17
* @route '/menu/stations'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/menu/stations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Menu\StationController::store
* @see app/Http/Controllers/Menu/StationController.php:17
* @route '/menu/stations'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Menu\StationController::store
* @see app/Http/Controllers/Menu/StationController.php:17
* @route '/menu/stations'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\StationController::store
* @see app/Http/Controllers/Menu/StationController.php:17
* @route '/menu/stations'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\StationController::store
* @see app/Http/Controllers/Menu/StationController.php:17
* @route '/menu/stations'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Menu\StationController::update
* @see app/Http/Controllers/Menu/StationController.php:32
* @route '/menu/stations/{station}'
*/
export const update = (args: { station: number | { id: number } } | [station: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/menu/stations/{station}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Menu\StationController::update
* @see app/Http/Controllers/Menu/StationController.php:32
* @route '/menu/stations/{station}'
*/
update.url = (args: { station: number | { id: number } } | [station: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { station: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { station: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            station: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        station: typeof args.station === 'object'
        ? args.station.id
        : args.station,
    }

    return update.definition.url
            .replace('{station}', parsedArgs.station.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Menu\StationController::update
* @see app/Http/Controllers/Menu/StationController.php:32
* @route '/menu/stations/{station}'
*/
update.put = (args: { station: number | { id: number } } | [station: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Menu\StationController::update
* @see app/Http/Controllers/Menu/StationController.php:32
* @route '/menu/stations/{station}'
*/
const updateForm = (args: { station: number | { id: number } } | [station: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Menu\StationController::update
* @see app/Http/Controllers/Menu/StationController.php:32
* @route '/menu/stations/{station}'
*/
updateForm.put = (args: { station: number | { id: number } } | [station: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const stations = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
}

export default stations