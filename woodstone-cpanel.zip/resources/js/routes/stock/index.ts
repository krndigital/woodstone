import items from './items'
import purchases from './purchases'
import orders from './orders'
import suppliers from './suppliers'
import recipes from './recipes'

const stock = {
    items: Object.assign(items, items),
    purchases: Object.assign(purchases, purchases),
    orders: Object.assign(orders, orders),
    suppliers: Object.assign(suppliers, suppliers),
    recipes: Object.assign(recipes, recipes),
}

export default stock