import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::index
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:32
* @route '/stock/orders'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/stock/orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::index
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:32
* @route '/stock/orders'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::index
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:32
* @route '/stock/orders'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::index
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:32
* @route '/stock/orders'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::index
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:32
* @route '/stock/orders'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::index
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:32
* @route '/stock/orders'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::index
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:32
* @route '/stock/orders'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::store
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:69
* @route '/stock/orders'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/stock/orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::store
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:69
* @route '/stock/orders'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::store
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:69
* @route '/stock/orders'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::store
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:69
* @route '/stock/orders'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::store
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:69
* @route '/stock/orders'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::status
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:103
* @route '/stock/orders/{purchaseOrder}/status'
*/
export const status = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/stock/orders/{purchaseOrder}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::status
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:103
* @route '/stock/orders/{purchaseOrder}/status'
*/
status.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { purchaseOrder: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            purchaseOrder: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        purchaseOrder: typeof args.purchaseOrder === 'object'
        ? args.purchaseOrder.id
        : args.purchaseOrder,
    }

    return status.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::status
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:103
* @route '/stock/orders/{purchaseOrder}/status'
*/
status.patch = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::status
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:103
* @route '/stock/orders/{purchaseOrder}/status'
*/
const statusForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::status
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:103
* @route '/stock/orders/{purchaseOrder}/status'
*/
statusForm.patch = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: status.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

status.form = statusForm

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::print
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:126
* @route '/stock/orders/{purchaseOrder}/print'
*/
export const print = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

print.definition = {
    methods: ["get","head"],
    url: '/stock/orders/{purchaseOrder}/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::print
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:126
* @route '/stock/orders/{purchaseOrder}/print'
*/
print.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { purchaseOrder: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            purchaseOrder: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        purchaseOrder: typeof args.purchaseOrder === 'object'
        ? args.purchaseOrder.id
        : args.purchaseOrder,
    }

    return print.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::print
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:126
* @route '/stock/orders/{purchaseOrder}/print'
*/
print.get = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::print
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:126
* @route '/stock/orders/{purchaseOrder}/print'
*/
print.head = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: print.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::print
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:126
* @route '/stock/orders/{purchaseOrder}/print'
*/
const printForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::print
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:126
* @route '/stock/orders/{purchaseOrder}/print'
*/
printForm.get = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\PurchaseOrderController::print
* @see app/Http/Controllers/Stock/PurchaseOrderController.php:126
* @route '/stock/orders/{purchaseOrder}/print'
*/
printForm.head = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: print.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

print.form = printForm

const orders = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    status: Object.assign(status, status),
    print: Object.assign(print, print),
}

export default orders