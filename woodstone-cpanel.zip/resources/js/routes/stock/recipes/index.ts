import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Stock\RecipeController::index
* @see app/Http/Controllers/Stock/RecipeController.php:25
* @route '/stock/recipes'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/stock/recipes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Stock\RecipeController::index
* @see app/Http/Controllers/Stock/RecipeController.php:25
* @route '/stock/recipes'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\RecipeController::index
* @see app/Http/Controllers/Stock/RecipeController.php:25
* @route '/stock/recipes'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\RecipeController::index
* @see app/Http/Controllers/Stock/RecipeController.php:25
* @route '/stock/recipes'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Stock\RecipeController::index
* @see app/Http/Controllers/Stock/RecipeController.php:25
* @route '/stock/recipes'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\RecipeController::index
* @see app/Http/Controllers/Stock/RecipeController.php:25
* @route '/stock/recipes'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Stock\RecipeController::index
* @see app/Http/Controllers/Stock/RecipeController.php:25
* @route '/stock/recipes'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Stock\RecipeController::update
* @see app/Http/Controllers/Stock/RecipeController.php:63
* @route '/stock/recipes/{menuItem}'
*/
export const update = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/stock/recipes/{menuItem}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Stock\RecipeController::update
* @see app/Http/Controllers/Stock/RecipeController.php:63
* @route '/stock/recipes/{menuItem}'
*/
update.url = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { menuItem: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { menuItem: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            menuItem: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        menuItem: typeof args.menuItem === 'object'
        ? args.menuItem.id
        : args.menuItem,
    }

    return update.definition.url
            .replace('{menuItem}', parsedArgs.menuItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\RecipeController::update
* @see app/Http/Controllers/Stock/RecipeController.php:63
* @route '/stock/recipes/{menuItem}'
*/
update.put = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Stock\RecipeController::update
* @see app/Http/Controllers/Stock/RecipeController.php:63
* @route '/stock/recipes/{menuItem}'
*/
const updateForm = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\RecipeController::update
* @see app/Http/Controllers/Stock/RecipeController.php:63
* @route '/stock/recipes/{menuItem}'
*/
updateForm.put = (args: { menuItem: number | { id: number } } | [menuItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const recipes = {
    index: Object.assign(index, index),
    update: Object.assign(update, update),
}

export default recipes