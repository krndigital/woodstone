import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Stock\SupplierController::store
* @see app/Http/Controllers/Stock/SupplierController.php:64
* @route '/stock/suppliers/{supplier}/payments'
*/
export const store = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/stock/suppliers/{supplier}/payments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Stock\SupplierController::store
* @see app/Http/Controllers/Stock/SupplierController.php:64
* @route '/stock/suppliers/{supplier}/payments'
*/
store.url = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { supplier: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { supplier: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            supplier: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        supplier: typeof args.supplier === 'object'
        ? args.supplier.id
        : args.supplier,
    }

    return store.definition.url
            .replace('{supplier}', parsedArgs.supplier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Stock\SupplierController::store
* @see app/Http/Controllers/Stock/SupplierController.php:64
* @route '/stock/suppliers/{supplier}/payments'
*/
store.post = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::store
* @see app/Http/Controllers/Stock/SupplierController.php:64
* @route '/stock/suppliers/{supplier}/payments'
*/
const storeForm = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Stock\SupplierController::store
* @see app/Http/Controllers/Stock/SupplierController.php:64
* @route '/stock/suppliers/{supplier}/payments'
*/
storeForm.post = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

const payments = {
    store: Object.assign(store, store),
}

export default payments