import settings from './settings'
import roles from './roles'

const admin = {
    settings: Object.assign(settings, settings),
    roles: Object.assign(roles, roles),
}

export default admin