import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SettingsController::remove
* @see app/Http/Controllers/Admin/SettingsController.php:91
* @route '/admin/settings/branding/{kind}'
*/
export const remove = (args: { kind: string | number } | [kind: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(args, options),
    method: 'delete',
})

remove.definition = {
    methods: ["delete"],
    url: '/admin/settings/branding/{kind}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\SettingsController::remove
* @see app/Http/Controllers/Admin/SettingsController.php:91
* @route '/admin/settings/branding/{kind}'
*/
remove.url = (args: { kind: string | number } | [kind: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kind: args }
    }

    if (Array.isArray(args)) {
        args = {
            kind: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kind: args.kind,
    }

    return remove.definition.url
            .replace('{kind}', parsedArgs.kind.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SettingsController::remove
* @see app/Http/Controllers/Admin/SettingsController.php:91
* @route '/admin/settings/branding/{kind}'
*/
remove.delete = (args: { kind: string | number } | [kind: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::remove
* @see app/Http/Controllers/Admin/SettingsController.php:91
* @route '/admin/settings/branding/{kind}'
*/
const removeForm = (args: { kind: string | number } | [kind: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: remove.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::remove
* @see app/Http/Controllers/Admin/SettingsController.php:91
* @route '/admin/settings/branding/{kind}'
*/
removeForm.delete = (args: { kind: string | number } | [kind: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: remove.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

remove.form = removeForm

const branding = {
    remove: Object.assign(remove, remove),
}

export default branding