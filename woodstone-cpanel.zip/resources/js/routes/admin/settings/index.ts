import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import branding3fced6 from './branding'
/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::edit
* @see app/Http/Controllers/Admin/SettingsController.php:25
* @route '/admin/settings'
*/
editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:34
* @route '/admin/settings'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/settings',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:34
* @route '/admin/settings'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:34
* @route '/admin/settings'
*/
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:34
* @route '/admin/settings'
*/
const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::update
* @see app/Http/Controllers/Admin/SettingsController.php:34
* @route '/admin/settings'
*/
updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\SettingsController::branding
* @see app/Http/Controllers/Admin/SettingsController.php:70
* @route '/admin/settings/branding'
*/
export const branding = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: branding.url(options),
    method: 'post',
})

branding.definition = {
    methods: ["post"],
    url: '/admin/settings/branding',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SettingsController::branding
* @see app/Http/Controllers/Admin/SettingsController.php:70
* @route '/admin/settings/branding'
*/
branding.url = (options?: RouteQueryOptions) => {
    return branding.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SettingsController::branding
* @see app/Http/Controllers/Admin/SettingsController.php:70
* @route '/admin/settings/branding'
*/
branding.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: branding.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::branding
* @see app/Http/Controllers/Admin/SettingsController.php:70
* @route '/admin/settings/branding'
*/
const brandingForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: branding.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SettingsController::branding
* @see app/Http/Controllers/Admin/SettingsController.php:70
* @route '/admin/settings/branding'
*/
brandingForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: branding.url(options),
    method: 'post',
})

branding.form = brandingForm

const settings = {
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    branding: Object.assign(branding, branding3fced6),
}

export default settings