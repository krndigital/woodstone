<?php

declare(strict_types=1);

namespace App\Enums;

enum OrderType: string
{
    case DineIn = 'dine_in';
    case Takeaway = 'takeaway';
    case Delivery = 'delivery';
    case Counter = 'counter';

    public function label(): string
    {
        return match ($this) {
            self::DineIn => 'Dine in',
            self::Takeaway => 'Takeaway',
            self::Delivery => 'Delivery',
            self::Counter => 'Counter',
        };
    }
}
